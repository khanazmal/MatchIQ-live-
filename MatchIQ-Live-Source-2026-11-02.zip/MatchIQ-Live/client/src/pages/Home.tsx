import { Activity, BarChart3, ChevronDown, CircleHelp, LayoutDashboard, LogIn, Menu, Radio, ShieldCheck, Trophy, UsersRound, X } from "lucide-react";
import { lazy, Suspense, useMemo, useState } from "react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { sampleAnalytics, sampleMatches, samplePlayerStatistics } from "@shared/cricket-samples";
import { MatchCard } from "@/components/cricket/MatchCard";
import { MatchDetails } from "@/components/cricket/MatchDetails";
import { PlayerStats } from "@/components/cricket/PlayerStats";
import "./cricket.css";

type Section = "overview" | "matches" | "players" | "analytics" | "manage";
type MatchFilter = "all" | "live" | "upcoming" | "completed";

const LIVE_MATCHES_REFRESH_MS = 30 * 60_000;
const LIVE_MATCHES_REFRESH_LABEL = "Checks every 30 min";
const AnalyticsPanel = lazy(() =>
  import("@/components/cricket/AnalyticsPanel").then(module => ({ default: module.AnalyticsPanel }))
);
const AdminPanel = lazy(() =>
  import("@/components/cricket/AdminPanel").then(module => ({ default: module.AdminPanel }))
);

const navigation: Array<{ id: Section; label: string; icon: typeof LayoutDashboard }> = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "matches", label: "Matches", icon: Radio },
  { id: "players", label: "Players", icon: UsersRound },
  { id: "analytics", label: "Analytics", icon: BarChart3 },
  { id: "manage", label: "Manage data", icon: ShieldCheck },
];

function formatDate(date: Date) {
  return date.toLocaleDateString([], { weekday: "long", month: "long", day: "numeric" });
}

function MetricCard({ label, value, note, icon: Icon, tone }: { label: string; value: string | number; note: string; icon: typeof Activity; tone: string }) {
  return <article className="cr-metric-card"><div className={`cr-metric-icon ${tone}`}><Icon size={18} /></div><span className="cr-metric-label">{label}</span><strong>{value}</strong><small>{note}</small></article>;
}

export default function Home() {
  const auth = useAuth();
  const [section, setSection] = useState<Section>("overview");
  const [filter, setFilter] = useState<MatchFilter>("all");
  const [selectedMatchId, setSelectedMatchId] = useState<number | null>(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const matchesQuery = trpc.cricket.matches.list.useQuery(undefined, {
    refetchInterval: LIVE_MATCHES_REFRESH_MS,
    staleTime: LIVE_MATCHES_REFRESH_MS,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    refetchIntervalInBackground: false,
    retry: false,
  });
  const playerQuery = trpc.cricket.players.statistics.useQuery(undefined, { retry: false });
  const analyticsQuery = trpc.cricket.analytics.overview.useQuery(undefined, { refetchInterval: 60_000, retry: false });

  const matches = matchesQuery.data?.items ?? (matchesQuery.isLoading ? [] : sampleMatches);
  const stats = playerQuery.data?.items ?? samplePlayerStatistics;
  const analytics = analyticsQuery.data ?? sampleAnalytics;
  const source = matchesQuery.data?.source ?? "sample";
  const notice = matchesQuery.data?.notice;
  const liveFeed = matchesQuery.data?.liveFeed;
  const feedStatus = matchesQuery.isLoading ? "loading" : matchesQuery.isError ? "error" : liveFeed?.status ?? "unconfigured";
  const bannerTone = feedStatus === "connected" ? "is-live" : feedStatus === "error" ? "is-error" : feedStatus === "empty" ? "is-empty" : feedStatus === "loading" ? "is-loading" : source === "database" ? "is-saved" : "is-demo";
  const feedTitle = feedStatus === "loading" ? "CONNECTING TO CRICKETLIVEAPI" : feedStatus === "error" ? "LIVE FEED UNAVAILABLE" : feedStatus === "connected" ? "LIVE SCORES · CRICKETLIVEAPI" : feedStatus === "empty" ? "CONNECTED · NO LIVE MATCHES" : source === "sample" ? "DEMO MODE · NO LIVE API CONNECTED" : "SAVED DATA · LIVE API NOT CONNECTED";
  const feedMessage = feedStatus === "loading" ? "Requesting the current live match feed…" : feedStatus === "error" ? "The live feed could not be loaded. Any saved or sample fixtures below retain their source labels." : feedStatus === "connected" ? `${liveFeed?.count ?? 0} in-progress match${liveFeed?.count === 1 ? "" : "es"} returned by CricketLiveAPI. ${liveFeed?.upcomingCount ? `${liveFeed.upcomingCount} provider upcoming/preview fixture${liveFeed.upcomingCount === 1 ? "" : "s"} also shown. ` : ""}${source === "sample" ? "Other sample fixtures remain labelled." : "Saved fixtures remain unchanged."}` : feedStatus === "empty" ? `CricketLiveAPI is authenticated, but no matches are in play right now. ${liveFeed?.upcomingCount ? `${liveFeed.upcomingCount} provider upcoming/preview fixture${liveFeed.upcomingCount === 1 ? "" : "s"} also shown. ` : ""}${source === "sample" ? "Upcoming and completed sample fixtures remain labelled." : "Saved fixtures remain unchanged."}` : notice ?? "Configure CRICKETLIVEAPI_TOKEN for this backend environment to enable live scores.";
  const filteredMatches = useMemo(() => filter === "all" ? matches : matches.filter(match => match.status === filter), [filter, matches]);
  const liveCount = matches.filter(match => match.status === "live").length;
  const scheduledCount = matches.filter(match => match.status === "upcoming").length;
  const completedCount = matches.filter(match => match.status === "completed").length;
  const liveMatch = matches.find(match => match.status === "live" && match.dataSource === "cricketliveapi") ?? matches.find(match => match.status === "live");
  const isAdmin = auth.user?.role === "admin";

  function chooseSection(next: Section) {
    setSection(next);
    setMobileNavOpen(false);
    if (next === "matches") setFilter("all");
  }

  return (
    <div className="cr-app-shell">
      <aside className={`cr-sidebar ${mobileNavOpen ? "is-open" : ""}`}>
        <div className="cr-brand"><span className="cr-brand-mark"><i /></span><span>Match<span>IQ</span><small>CRICKET INTELLIGENCE</small></span><button className="cr-mobile-close" type="button" onClick={() => setMobileNavOpen(false)} aria-label="Close menu"><X size={18} /></button></div>
        <div className="cr-sidebar-label">WORKSPACE</div>
        <nav className="cr-nav" aria-label="Main navigation">
          {navigation.map(({ id, label, icon: Icon }) => <button key={id} type="button" className={`cr-nav-item ${section === id ? "is-active" : ""} ${id === "manage" && !isAdmin ? "is-subtle" : ""}`} onClick={() => chooseSection(id)}><Icon size={17} /><span>{label}</span>{id === "matches" && liveCount > 0 && <em>{liveCount}</em>}</button>)}
        </nav>
        <div className="cr-sidebar-bottom"><div className="cr-season-card"><span className="cr-live-pip"/><div><strong>Demo season</strong><small>MatchIQ Sample League</small></div><ChevronDown size={14} /></div><div className="cr-sidebar-help"><CircleHelp size={16} /><span>Sample scores are fictional</span></div></div>
      </aside>
      {mobileNavOpen && <button className="cr-mobile-scrim" type="button" onClick={() => setMobileNavOpen(false)} aria-label="Close navigation" />}
      <div className="cr-main-column">
        <header className="cr-topbar"><div className="cr-topbar-left"><button className="cr-mobile-menu" type="button" onClick={() => setMobileNavOpen(true)} aria-label="Open menu"><Menu size={20} /></button><span className="cr-breadcrumb">Workspace <b>/</b> {navigation.find(item => item.id === section)?.label}</span></div><div className="cr-topbar-actions"><span className="cr-topbar-date">{formatDate(new Date())}</span><div className="cr-user-menu">{auth.user ? <><span className="cr-user-avatar">{(auth.user.name || auth.user.email || "M").slice(0, 1).toUpperCase()}</span><span className="cr-user-name">{auth.user.name || "Member"}</span><button className="cr-user-action" type="button" onClick={() => void auth.logout()} aria-label="Sign out">Sign out</button></> : <button type="button" className="cr-signin-button" onClick={() => startLogin()}><LogIn size={15} /> Sign in</button>}</div></div></header>
        <main className="cr-main-content">
          <div className={`cr-feed-banner ${bannerTone}`} role="status" aria-live="polite"><span className="cr-banner-icon"><Radio size={15} /></span><div><strong>{feedTitle}</strong><span>{feedMessage}</span></div><span className="cr-feed-refresh">{matchesQuery.isFetching && !matchesQuery.isLoading ? "Refreshing…" : LIVE_MATCHES_REFRESH_LABEL}</span></div>

          {section === "overview" && <>
            <section className="cr-page-intro"><div><span className="cr-eyebrow">WEDNESDAY · MATCH CENTRE</span><h1>Cricket, in context<span>.</span></h1><p>Scores, players and match-day numbers—together in one view.</p></div><button className="cr-primary-button" type="button" onClick={() => chooseSection("matches")}><Radio size={16} /> Open match centre</button></section>
            <section className="cr-metrics-grid" aria-label="Dashboard totals">
              <MetricCard label="Live matches" value={liveCount.toString().padStart(2, "0")} note="Saved or sample fixtures" icon={Radio} tone="metric-lime" />
              <MetricCard label="Scheduled" value={scheduledCount.toString().padStart(2, "0")} note="Coming up next" icon={Activity} tone="metric-blue" />
              <MetricCard label="Runs on record" value={(analytics.totalRuns ?? 0).toLocaleString()} note={analytics.source === "sample" ? "Illustrative sample total" : "SQL innings aggregate"} icon={BarChart3} tone="metric-violet" />
              <MetricCard label="Matches wrapped" value={completedCount.toString().padStart(2, "0")} note="Completed fixtures" icon={Trophy} tone="metric-orange" />
            </section>
            <div className="cr-overview-grid">
              <section className="cr-panel cr-featured-panel"><div className="cr-panel-heading"><div><span className="cr-eyebrow">MATCH CENTRE</span><h2>On the field</h2></div><button className="cr-text-button" type="button" onClick={() => chooseSection("matches")}>All matches <span>→</span></button></div>{feedStatus === "loading" ? <div className="cr-empty-state" role="status">Loading live matches from CricketLiveAPI…</div> : matchesQuery.isError || feedStatus === "error" ? <div className="cr-empty-state" role="alert">The live feed is unavailable. Saved or sample fixtures remain clearly identified below.</div> : feedStatus === "empty" ? <div className="cr-empty-state" role="status">No matches are in play in the latest CricketLiveAPI response. Upcoming/preview fixtures appear under Scheduled.</div> : liveMatch ? <MatchCard match={liveMatch} onOpen={setSelectedMatchId} /> : <div className="cr-empty-state">No match is marked live right now.</div>}</section>
              <section className="cr-panel cr-quick-panel"><div className="cr-panel-heading"><div><span className="cr-eyebrow">QUICK READ</span><h2>Today’s board</h2></div><Activity size={17} className="cr-panel-icon" /></div><div className="cr-quick-stat"><span><i className="cr-dot dot-lime"/> Live</span><strong>{liveCount}</strong></div><div className="cr-quick-stat"><span><i className="cr-dot dot-blue"/> Upcoming</span><strong>{scheduledCount}</strong></div><div className="cr-quick-stat"><span><i className="cr-dot dot-muted"/> Completed</span><strong>{completedCount}</strong></div><div className="cr-quick-note"><span className="cr-quick-note-mark">IQ</span><p>{stats.length} player profiles in this view. <button type="button" onClick={() => chooseSection("players")}>Explore stats →</button></p></div></section>
            </div>
            <section className="cr-panel cr-match-list-panel"><div className="cr-panel-heading"><div><span className="cr-eyebrow">FIXTURES</span><h2>Recent & upcoming</h2><p>Sample fixtures are clearly identified above.</p></div><button className="cr-text-button" type="button" onClick={() => chooseSection("matches")}>View match centre <span>→</span></button></div><div className="cr-match-grid">{matches.slice(0, 3).map(match => <MatchCard key={match.id} match={match} onOpen={setSelectedMatchId} />)}</div></section>
            <div className="cr-overview-grid cr-lower-grid"><section className="cr-panel cr-mini-chart"><div className="cr-panel-heading"><div><span className="cr-eyebrow">SQL INSIGHTS</span><h2>Team run totals</h2><p>{analytics.source === "sample" ? "Illustrative sample values" : "Aggregated from innings"}</p></div><button className="cr-text-button" type="button" onClick={() => chooseSection("analytics")}>Explore <span>→</span></button></div><div className="cr-mini-bars">{analytics.teamRuns.slice(0, 4).map(team => <div className="cr-mini-bar-row" key={team.name}><span>{team.name}</span><div><i style={{ width: `${Math.max(6, (team.runs / Math.max(...analytics.teamRuns.map(item => item.runs), 1)) * 100)}%` }} /></div><b>{team.runs}</b></div>)}</div></section><section className="cr-panel cr-player-spotlight"><div className="cr-panel-heading"><div><span className="cr-eyebrow">PLAYER TO WATCH</span><h2>{stats[0]?.playerName ?? "Player stats"}</h2><p>{stats[0]?.teamName ?? "—"} · current runs leader</p></div><span className="cr-spotlight-star">✦</span></div><div className="cr-spotlight-number">{stats[0]?.runs ?? 0}<small>RUNS</small></div><div className="cr-spotlight-footer"><span>AVG <b>{stats[0]?.battingAverage.toFixed(2) ?? "0.00"}</b></span><span>SR <b>{stats[0]?.strikeRate.toFixed(1) ?? "0.0"}</b></span><button type="button" onClick={() => chooseSection("players")}>Full leaderboard →</button></div></section></div>
          </>}

          {section === "matches" && <section className="cr-page-section"><div className="cr-page-intro cr-section-intro"><div><span className="cr-eyebrow">FIXTURES & SCOREBOARDS</span><h1>Match centre<span>.</span></h1><p>Choose a fixture to open its innings, scorecards and key partnerships.</p></div><span className="cr-result-count">{filteredMatches.length} fixtures</span></div><div className="cr-filter-row" role="tablist" aria-label="Filter matches">{(["all", "live", "upcoming", "completed"] as MatchFilter[]).map(item => <button key={item} type="button" role="tab" aria-selected={filter === item} className={filter === item ? "is-active" : ""} onClick={() => setFilter(item)}>{item === "all" ? "All matches" : item.charAt(0).toUpperCase() + item.slice(1)}{item !== "all" && <span>{matches.filter(match => match.status === item).length}</span>}</button>)}</div><div className="cr-match-grid cr-match-grid-page">{filteredMatches.map(match => <MatchCard key={match.id} match={match} onOpen={setSelectedMatchId} />)}</div>{filteredMatches.length === 0 && <div className="cr-panel cr-empty-state" role="status">{filter === "live" && feedStatus === "empty" ? "No matches are in play in the latest CricketLiveAPI response." : filter === "live" && feedStatus === "loading" ? "Loading live matches from CricketLiveAPI…" : filter === "live" && (matchesQuery.isError || feedStatus === "error") ? "Live match data could not be loaded. Check the feed status above." : "No fixtures in this category yet."}</div>}</section>}

          {section === "players" && <section className="cr-page-section"><div className="cr-page-intro cr-section-intro"><div><span className="cr-eyebrow">PLAYER ROOM</span><h1>Numbers, by player<span>.</span></h1><p>Search and sort the batting and bowling leaderboard.</p></div></div><PlayerStats items={stats} source={playerQuery.data?.source ?? "sample"} /></section>}

          {section === "analytics" && <section className="cr-page-section"><div className="cr-page-intro cr-section-intro"><div><span className="cr-eyebrow">MATCHIQ ANALYTICS</span><h1>Patterns behind the score<span>.</span></h1><p>SQL aggregates when database records exist; sample charts are marked.</p></div><div className="cr-analytics-totals"><span>RUNS <b>{(analytics.totalRuns ?? 0).toLocaleString()}</b></span><span>WICKETS <b>{analytics.totalWickets ?? 0}</b></span></div></div><Suspense fallback={<div className="cr-empty-state" role="status">Loading analytics charts…</div>}><AnalyticsPanel data={analytics} /></Suspense></section>}

          {section === "manage" && <section className="cr-page-section"><div className="cr-page-intro cr-section-intro"><div><span className="cr-eyebrow">DATA WORKSPACE</span><h1>Manage the scorebook<span>.</span></h1><p>Create and maintain cricket records with administrator access.</p></div></div>{auth.loading ? <div className="cr-panel cr-empty-state">Checking administrator access…</div> : isAdmin ? <Suspense fallback={<div className="cr-panel cr-empty-state" role="status">Loading scorebook tools…</div>}><AdminPanel /></Suspense> : <section className="cr-panel cr-admin-gate"><span className="cr-admin-lock"><ShieldCheck size={22} /></span><h2>Administrator sign-in required</h2><p>Record changes are protected. Sign in with an account whose existing project role is <b>admin</b>. Your current sign-in and account records are unchanged.</p>{auth.isAuthenticated ? <span className="cr-source-tag">Current role: {auth.user?.role ?? "user"}</span> : <button className="cr-primary-button" onClick={() => startLogin()} type="button"><LogIn size={16} /> Sign in securely</button>}</section>}</section>}

          <footer className="cr-footer"><span>MatchIQ · cricket data, kept in context</span><span><i className={`cr-footer-dot ${feedStatus === "connected" ? "is-live" : ""}`}/> API status: {feedStatus === "connected" ? "connected · live matches" : feedStatus === "empty" ? "connected · no in-play matches" : feedStatus === "loading" ? "checking live feed" : feedStatus === "error" ? "feed unavailable" : "not connected"}</span></footer>
        </main>
      </div>
      <MatchDetails matchId={selectedMatchId} onClose={() => setSelectedMatchId(null)} />
    </div>
  );
}
