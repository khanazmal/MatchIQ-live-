import { X } from "lucide-react";
import { trpc } from "@/lib/trpc";
import type { CricketMatchCard } from "@shared/cricket-samples";
import { formatOvers } from "@shared/cricket-utils";
import { MatchStatus, TeamMark } from "./MatchCard";

export function MatchDetails({ matchId, onClose }: { matchId: number | null; onClose: () => void }) {
  const detailQuery = trpc.cricket.matches.detail.useQuery({ id: matchId ?? -1 }, { enabled: matchId !== null, retry: false });
  const match = detailQuery.data as CricketMatchCard | undefined;
  if (matchId === null) return null;

  return (
    <div className="cr-dialog-backdrop" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }}>
      <section className="cr-dialog" role="dialog" aria-modal="true" aria-label="Match details">
        <button className="cr-dialog-close" type="button" onClick={onClose} aria-label="Close match details"><X size={19} /></button>
        {detailQuery.isLoading && <div className="cr-empty-state">Loading match details…</div>}
        {detailQuery.isError && <div className="cr-empty-state">{detailQuery.error.message}</div>}
        {match && <>
          <div className="cr-dialog-kicker"><span className="cr-eyebrow">{match.competition ?? "MATCH CENTRE"}</span><MatchStatus status={match.status} sample={match.dataSource === "sample"} /></div>
          <h2 className="cr-dialog-title">{match.teamA.name} <span>v</span> {match.teamB.name}</h2>
          <p className="cr-dialog-subtitle">{match.title} · {match.format}{match.venue ? ` · ${match.venue}` : ""}</p>
          {match.dataSource === "sample" && <div className="cr-demo-strip">Fictional sample match data — not a live provider feed.</div>}
          {match.dataSource === "cricketliveapi" && <div className="cr-result-banner">{match.status === "live" ? "CricketLiveAPI live score" : match.status === "upcoming" ? "CricketLiveAPI upcoming fixture" : "CricketLiveAPI match details"}{match.liveScore ? ` · ${match.liveScore}` : ""}</div>}
          {match.result && <div className="cr-result-banner">{match.result}</div>}
          {match.summary && <p className="cr-summary-text">{match.summary}</p>}
          <div className="cr-innings-list">
            {match.innings.length === 0 && <div className="cr-empty-state">{match.dataSource === "cricketliveapi" ? match.status === "live" ? "The live-matches endpoint does not include a full innings scorecard." : "No innings scorecard is available for this provider fixture yet." : "No innings scorecard has been recorded yet."}</div>}
            {match.innings.map(inning => {
              const battingTeam = inning.battingTeamId === match.teamA.id ? match.teamA : match.teamB;
              const bowlingTeam = inning.bowlingTeamId === match.teamA.id ? match.teamA : match.teamB;
              return <article className="cr-innings-card" key={inning.id}>
                <div className="cr-innings-heading"><div><span className="cr-eyebrow">INNINGS {inning.inningsNumber}</span><h3><TeamMark code={battingTeam.shortName} /> {battingTeam.name}</h3></div><div className="cr-innings-total"><b>{inning.totalRuns}/{inning.wickets}</b><span>{formatOvers(inning.legalBalls)} overs</span></div></div>
                {inning.target && <div className="cr-target-line">Target {inning.target} · {bowlingTeam.shortName} bowling</div>}
                <div className="cr-scorecard-grid">
                  <div><h4>Batting</h4><div className="cr-table-wrap"><table className="cr-table cr-score-table"><thead><tr><th>Batter</th><th>R</th><th>B</th><th>4s</th><th>6s</th></tr></thead><tbody>{inning.batting.map(player => <tr key={player.id}><td><span className="cr-score-player">{player.playerName}</span><small>{player.dismissal ?? (player.isNotOut ? "not out" : "—")}</small></td><td><b>{player.runs}</b></td><td>{player.ballsFaced}</td><td>{player.fours}</td><td>{player.sixes}</td></tr>)}</tbody></table></div></div>
                  <div><h4>Bowling</h4><div className="cr-table-wrap"><table className="cr-table cr-score-table"><thead><tr><th>Bowler</th><th>O</th><th>R</th><th>W</th></tr></thead><tbody>{inning.bowling.map(player => <tr key={player.id}><td><span className="cr-score-player">{player.playerName}</span><small>{player.maidens} maiden · {player.wides + player.noBalls} extras</small></td><td>{formatOvers(player.legalBalls)}</td><td>{player.runsConceded}</td><td><b>{player.wickets}</b></td></tr>)}</tbody></table></div></div>
                </div>
                {inning.partnerships.length > 0 && <div className="cr-partnerships"><h4>Key partnerships</h4>{inning.partnerships.map((pair, index) => <div className="cr-partnership-row" key={`${pair.wicketNumber}-${index}`}><span>Wicket {pair.wicketNumber}</span><strong>{pair.batterOne} + {pair.batterTwo}</strong><b>{pair.runs} <small>({pair.balls} balls)</small></b></div>)}</div>}
              </article>;
            })}
          </div>
        </>}
      </section>
    </div>
  );
}
