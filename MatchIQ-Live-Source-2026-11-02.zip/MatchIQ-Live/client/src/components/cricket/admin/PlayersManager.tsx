import { useState, type FormEvent } from "react";
import { trpc } from "@/lib/trpc";
import { AdminDeleteButton, AdminEditButton, AdminField, AdminFormActions, AdminRecordList, reportAdminError } from "./AdminElements";

type PlayerForm = { id: number | null; fullName: string; teamId: string; role: "batter" | "bowler" | "all_rounder" | "wicket_keeper"; battingStyle: string; bowlingStyle: string; country: string };
const blank: PlayerForm = { id: null, fullName: "", teamId: "", role: "all_rounder", battingStyle: "", bowlingStyle: "", country: "" };

export function PlayersManager({ onSaved }: { onSaved: () => Promise<void> }) {
  const [form, setForm] = useState<PlayerForm>(blank);
  const query = trpc.cricket.admin.players.list.useQuery(undefined, { retry: false });
  const teams = trpc.cricket.admin.teams.list.useQuery(undefined, { retry: false });
  const create = trpc.cricket.admin.players.create.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const update = trpc.cricket.admin.players.update.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const remove = trpc.cricket.admin.players.delete.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const set = (key: keyof PlayerForm, value: string) => setForm(old => ({ ...old, [key]: value }));
  async function submit(event: FormEvent) {
    event.preventDefault();
    const data = { fullName: form.fullName, teamId: form.teamId ? Number(form.teamId) : null, role: form.role, battingStyle: form.battingStyle || null, bowlingStyle: form.bowlingStyle || null, country: form.country || null };
    if (form.id) await update.mutateAsync({ id: form.id, data }); else await create.mutateAsync(data);
    setForm(blank);
  }
  return <div className="cr-admin-grid">
    <form className="cr-admin-form" onSubmit={event => void submit(event)}><span className="cr-eyebrow">PLAYER RECORD</span><h3>{form.id ? "Edit player" : "Add a player"}</h3>
      <AdminField label="Player name"><input className="cr-input" required minLength={2} maxLength={160} value={form.fullName} onChange={event => set("fullName", event.target.value)} placeholder="Full name" /></AdminField>
      <div className="cr-admin-fields-two"><AdminField label="Team"><select className="cr-input" value={form.teamId} onChange={event => set("teamId", event.target.value)}><option value="">No team assigned</option>{teams.data?.map(team => <option value={team.id} key={team.id}>{team.shortName} — {team.name}</option>)}</select></AdminField><AdminField label="Playing role"><select className="cr-input" value={form.role} onChange={event => set("role", event.target.value as PlayerForm["role"])}><option value="batter">Batter</option><option value="bowler">Bowler</option><option value="all_rounder">All-rounder</option><option value="wicket_keeper">Wicket-keeper</option></select></AdminField></div>
      <div className="cr-admin-fields-two"><AdminField label="Batting style"><input className="cr-input" value={form.battingStyle} onChange={event => set("battingStyle", event.target.value)} placeholder="Right-hand bat" /></AdminField><AdminField label="Bowling style"><input className="cr-input" value={form.bowlingStyle} onChange={event => set("bowlingStyle", event.target.value)} placeholder="Right-arm medium" /></AdminField></div>
      <AdminField label="Country (optional)"><input className="cr-input" value={form.country} onChange={event => set("country", event.target.value)} placeholder="Country" /></AdminField>
      <AdminFormActions editing={Boolean(form.id)} onCancel={() => setForm(blank)} />
    </form>
    <AdminRecordList title="Saved players" emptyText={query.isLoading ? "Loading players…" : query.error ? query.error.message : "No saved player profiles yet."}>
      {query.data?.map(player => <div className="cr-admin-record-row" key={player.id}><span className="cr-player-rank">{player.fullName.slice(0, 1).toUpperCase()}</span><div className="cr-admin-record-main"><strong>{player.fullName}</strong><small>{player.role.replaceAll("_", " ")} · {teams.data?.find(team => team.id === player.teamId)?.shortName ?? "No team"}</small></div><AdminEditButton label={player.fullName} onEdit={() => setForm({ id: player.id, fullName: player.fullName, teamId: player.teamId ? String(player.teamId) : "", role: player.role, battingStyle: player.battingStyle ?? "", bowlingStyle: player.bowlingStyle ?? "", country: player.country ?? "" })} /><AdminDeleteButton label={player.fullName} onDelete={() => remove.mutate({ id: player.id })} /></div>)}
    </AdminRecordList>
  </div>;
}
