import { Pencil, Plus, Trash2, X } from "lucide-react";
import { Children, type ReactNode } from "react";
import { toast } from "sonner";

export function AdminRecordList({ title, emptyText, children }: { title: string; emptyText: string; children: ReactNode }) {
  return <div className="cr-admin-record-list"><div className="cr-admin-list-title"><h3>{title}</h3></div>{Children.count(children) > 0 ? children : <p className="cr-admin-empty">{emptyText}</p>}</div>;
}

export function AdminField({ label, children }: { label: string; children: ReactNode }) {
  return <label className="cr-admin-field"><span>{label}</span>{children}</label>;
}

export function AdminFormActions({ editing, onCancel }: { editing: boolean; onCancel: () => void }) {
  return <div className="cr-admin-form-actions"><button className="cr-admin-submit" type="submit"><span>{editing ? <Pencil size={14} /> : <Plus size={14} />}</span>{editing ? "Save changes" : "Add record"}</button>{editing && <button className="cr-admin-cancel" type="button" onClick={onCancel}><X size={14} /> Cancel edit</button>}</div>;
}

export function AdminDeleteButton({ onDelete, label }: { onDelete: () => void; label: string }) {
  return <button className="cr-admin-icon-button is-delete" type="button" aria-label={`Delete ${label}`} title={`Delete ${label}`} onClick={() => { if (window.confirm(`Delete ${label}? This cannot be undone.`)) onDelete(); }}><Trash2 size={14} /></button>;
}

export function AdminEditButton({ onEdit, label }: { onEdit: () => void; label: string }) {
  return <button className="cr-admin-icon-button" type="button" aria-label={`Edit ${label}`} title={`Edit ${label}`} onClick={onEdit}><Pencil size={14} /></button>;
}

export function reportAdminError(error: { message: string }) {
  toast.error(error.message || "The record could not be saved.");
}
