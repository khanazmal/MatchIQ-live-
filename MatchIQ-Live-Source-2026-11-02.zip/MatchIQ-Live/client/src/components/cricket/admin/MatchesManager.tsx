import { useState, type FormEvent } from "react";
import { trpc } from "@/lib/trpc";
import { AdminDeleteButton, AdminEditButton, AdminField, AdminFormActions, AdminRecordList, reportAdminError } from "./AdminElements";

type MatchForm = { id: number | null; title: string; format: "T20" | "ODI" | "Test" | "T10" | "Other"; competition: string; venue: string; scheduledAt: string; status: "upcoming" | "live" | "completed" | "abandoned"; teamAId: string; teamBId: string; result: string; summary: string };
const blank: MatchForm = { id: null, title: "", format: "T20", competition: "", venue: "", scheduledAt: "", status: "upcoming", teamAId: "", teamBId: "", result: "", summary: "" };

export function MatchesManager({ onSaved }: { onSaved: () => Promise<void> }) {
  const [form, setForm] = useState<MatchForm>(blank);
  const query = trpc.cricket.admin.matches.list.useQuery(undefined, { retry: false });
  const teams = trpc.cricket.admin.teams.list.useQuery(undefined, { retry: false });
  const create = trpc.cricket.admin.matches.create.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const update = trpc.cricket.admin.matches.update.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const remove = trpc.cricket.admin.matches.delete.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const set = (key: keyof MatchForm, value: string) => setForm(old => ({ ...old, [key]: value }));
  async function submit(event: FormEvent) {
    event.preventDefault();
    const data = { title: form.title, format: form.format, competition: form.competition || null, venue: form.venue || null, scheduledAt: new Date(form.scheduledAt), status: form.status, teamAId: Number(form.teamAId), teamBId: Number(form.teamBId), result: form.result || null, summary: form.summary || null };
    if (form.id) await update.mutateAsync({ id: form.id, data }); else await create.mutateAsync(data);
    setForm(blank);
  }
  function edit(match: NonNullable<typeof query.data>[number]) {
    const scheduledAt = new Date(match.scheduledAt);
    const localDateTime = new Date(scheduledAt.getTime() - scheduledAt.getTimezoneOffset() * 60_000).toISOString().slice(0, 16);
    setForm({ id: match.id, title: match.title, format: match.format, competition: match.competition ?? "", venue: match.venue ?? "", scheduledAt: localDateTime, status: match.status, teamAId: String(match.teamAId), teamBId: String(match.teamBId), result: match.result ?? "", summary: match.summary ?? "" });
  }
  return <div className="cr-admin-grid">
    <form className="cr-admin-form" onSubmit={event => void submit(event)}><span className="cr-eyebrow">FIXTURE RECORD</span><h3>{form.id ? "Edit match" : "Schedule a match"}</h3>
      <AdminField label="Fixture title"><input className="cr-input" required minLength={3} maxLength={180} value={form.title} onChange={event => set("title", event.target.value)} placeholder="e.g. Match 14 · Day fixture" /></AdminField>
      <div className="cr-admin-fields-two"><AdminField label="Format"><select className="cr-input" value={form.format} onChange={event => set("format", event.target.value as MatchForm["format"])}><option>T20</option><option>ODI</option><option>Test</option><option>T10</option><option>Other</option></select></AdminField><AdminField label="Status"><select className="cr-input" value={form.status} onChange={event => set("status", event.target.value as MatchForm["status"])}><option value="upcoming">Upcoming</option><option value="live">Live (manual)</option><option value="completed">Completed</option><option value="abandoned">Abandoned</option></select></AdminField></div>
      <div className="cr-admin-fields-two"><AdminField label="Team A"><select className="cr-input" required value={form.teamAId} onChange={event => set("teamAId", event.target.value)}><option value="">Choose a team</option>{teams.data?.map(team => <option key={team.id} value={team.id}>{team.shortName} — {team.name}</option>)}</select></AdminField><AdminField label="Team B"><select className="cr-input" required value={form.teamBId} onChange={event => set("teamBId", event.target.value)}><option value="">Choose a team</option>{teams.data?.map(team => <option key={team.id} value={team.id}>{team.shortName} — {team.name}</option>)}</select></AdminField></div>
      <AdminField label="Start time"><input className="cr-input" type="datetime-local" required value={form.scheduledAt} onChange={event => set("scheduledAt", event.target.value)} /></AdminField>
      <div className="cr-admin-fields-two"><AdminField label="Competition"><input className="cr-input" value={form.competition} onChange={event => set("competition", event.target.value)} placeholder="League or tournament" /></AdminField><AdminField label="Venue"><input className="cr-input" value={form.venue} onChange={event => set("venue", event.target.value)} placeholder="Ground / city" /></AdminField></div>
      {form.status === "completed" && <AdminField label="Result"><input className="cr-input" value={form.result} onChange={event => set("result", event.target.value)} placeholder="Team won by …" /></AdminField>}
      <AdminField label="Short match summary"><textarea className="cr-input cr-textarea" maxLength={5000} value={form.summary} onChange={event => set("summary", event.target.value)} placeholder="A short note for the match detail panel" /></AdminField>
      <AdminFormActions editing={Boolean(form.id)} onCancel={() => setForm(blank)} />
    </form>
    <AdminRecordList title="Saved fixtures" emptyText={query.isLoading ? "Loading matches…" : query.error ? query.error.message : "No saved matches yet. Create one after you add teams."}>
      {query.data?.map(match => <div className="cr-admin-record-row" key={match.id}><span className={`cr-admin-status-dot status-${match.status}`} /><div className="cr-admin-record-main"><strong>{match.title}</strong><small>{match.format} · {teams.data?.find(team => team.id === match.teamAId)?.shortName ?? "?"} v {teams.data?.find(team => team.id === match.teamBId)?.shortName ?? "?"} · {match.status}</small></div><AdminEditButton label={match.title} onEdit={() => edit(match)} /><AdminDeleteButton label={match.title} onDelete={() => remove.mutate({ id: match.id })} /></div>)}
    </AdminRecordList>
  </div>;
}
