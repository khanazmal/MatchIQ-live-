import { useState, type FormEvent } from "react";
import { trpc } from "@/lib/trpc";
import { AdminDeleteButton, AdminEditButton, AdminField, AdminFormActions, AdminRecordList, reportAdminError } from "./AdminElements";

type TeamForm = { id: number | null; name: string; shortName: string; country: string; logoUrl: string };
const blank: TeamForm = { id: null, name: "", shortName: "", country: "", logoUrl: "" };

export function TeamsManager({ onSaved }: { onSaved: () => Promise<void> }) {
  const [form, setForm] = useState<TeamForm>(blank);
  const query = trpc.cricket.admin.teams.list.useQuery(undefined, { retry: false });
  const create = trpc.cricket.admin.teams.create.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const update = trpc.cricket.admin.teams.update.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const remove = trpc.cricket.admin.teams.delete.useMutation({ onSuccess: onSaved, onError: reportAdminError });
  const busy = create.isPending || update.isPending;
  const set = (key: keyof TeamForm, value: string) => setForm(old => ({ ...old, [key]: value }));
  async function submit(event: FormEvent) {
    event.preventDefault();
    const data = { name: form.name, shortName: form.shortName.toUpperCase(), country: form.country, logoUrl: form.logoUrl || null };
    if (form.id) await update.mutateAsync({ id: form.id, data });
    else await create.mutateAsync(data);
    setForm(blank);
  }
  return <div className="cr-admin-grid">
    <form className="cr-admin-form" onSubmit={event => void submit(event)}><span className="cr-eyebrow">TEAM RECORD</span><h3>{form.id ? "Edit team" : "Add a team"}</h3>
      <AdminField label="Full team name"><input className="cr-input" required minLength={2} maxLength={120} value={form.name} onChange={event => set("name", event.target.value)} placeholder="e.g. Harbour Strikers" /></AdminField>
      <div className="cr-admin-fields-two"><AdminField label="Short code"><input className="cr-input" required minLength={2} maxLength={12} value={form.shortName} onChange={event => set("shortName", event.target.value)} placeholder="HBS" /></AdminField><AdminField label="Country / league"><input className="cr-input" required value={form.country} onChange={event => set("country", event.target.value)} placeholder="India" /></AdminField></div>
      <AdminField label="Logo URL (optional)"><input className="cr-input" type="url" value={form.logoUrl} onChange={event => set("logoUrl", event.target.value)} placeholder="https://…" /></AdminField>
      <AdminFormActions editing={Boolean(form.id)} onCancel={() => setForm(blank)} />
      {busy && <p className="cr-admin-hint">Saving record…</p>}
    </form>
    <AdminRecordList title="Saved teams" emptyText={query.isLoading ? "Loading teams…" : query.error ? query.error.message : "No saved teams yet. Create the first one."}>
      {query.data?.map(team => <div className="cr-admin-record-row" key={team.id}><span className="cr-team-mark cr-team-mark-lime">{team.shortName.slice(0, 3)}</span><div className="cr-admin-record-main"><strong>{team.name}</strong><small>{team.shortName} · {team.country}</small></div><AdminEditButton label={team.name} onEdit={() => setForm({ id: team.id, name: team.name, shortName: team.shortName, country: team.country, logoUrl: team.logoUrl ?? "" })} /><AdminDeleteButton label={team.name} onDelete={() => remove.mutate({ id: team.id })} /></div>)}
    </AdminRecordList>
  </div>;
}
