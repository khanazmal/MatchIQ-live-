import { ArrowUpRight, Clock3, MapPin } from "lucide-react";
import type { CricketMatchCard } from "@shared/cricket-samples";
import { formatOvers } from "@shared/cricket-utils";

export function MatchStatus({ status, sample = false }: { status: CricketMatchCard["status"]; sample?: boolean }) {
  const label = sample && status === "live" ? "Sample live" : status === "live" ? "Live" : status === "upcoming" ? "Upcoming" : status === "completed" ? "Completed" : "Abandoned";
  return <span className={`cr-status cr-status-${status}`}><i />{label}</span>;
}

export function TeamMark({ code, tone = "lime" }: { code: string; tone?: "lime" | "blue" | "orange" }) {
  return <span className={`cr-team-mark cr-team-mark-${tone}`}>{code.slice(0, 3).toUpperCase()}</span>;
}

function getInnings(match: CricketMatchCard, teamId: number) {
  return match.innings.find(inning => inning.battingTeamId === teamId);
}

export function MatchCard({ match, onOpen }: { match: CricketMatchCard; onOpen: (id: number) => void }) {
  const first = getInnings(match, match.teamA.id);
  const second = getInnings(match, match.teamB.id);
  const current = match.innings.find(inning => inning.inningsNumber === match.currentInnings) ?? match.innings.at(-1);
  const firstScore = match.teamAScore ?? (first ? `${first.totalRuns}/${first.wickets}` : "—");
  const secondScore = match.teamBScore ?? (second ? `${second.totalRuns}/${second.wickets}` : "—");
  const firstOvers = first ? formatOvers(first.legalBalls) : "0.0";
  const secondOvers = second ? formatOvers(second.legalBalls) : "0.0";
  const providerScore = match.dataSource === "cricketliveapi" && match.status === "live" && Boolean(match.teamAScore || match.teamBScore);
  const showLiveScoreSummary = match.liveScore && !providerScore;
  const startTime = new Date(match.scheduledAt);
  const matchSummary = match.result ?? match.summary ?? (match.liveScore
    ? match.dataSource === "cricketliveapi" && match.status === "live" ? "Live score · CricketLiveAPI" : match.liveScore
    : match.status === "live" && current ? `${current.totalRuns}/${current.wickets} · ${formatOvers(current.legalBalls)} overs`
      : match.status === "upcoming" ? startTime.toLocaleString([], { weekday: "short", hour: "numeric", minute: "2-digit" })
        : "Match summary");

  return (
    <button className="cr-match-card" onClick={() => onOpen(match.id)} type="button" aria-label={`Open ${match.teamA.name} versus ${match.teamB.name}`}>
      <div className="cr-match-card-top">
        <div className="cr-match-meta"><span className="cr-format-tag">{match.format}</span><span>{match.competition ?? "Cricket fixture"}</span>{match.dataSource === "cricketliveapi" && <span className="cr-provider-badge" aria-label="CricketLiveAPI provider fixture">PROVIDER</span>}{match.dataSource === "sample" && <span className="cr-sample-badge">SAMPLE</span>}</div>
        <MatchStatus status={match.status} sample={match.dataSource === "sample"} />
      </div>
      <div className="cr-match-title">{match.title}</div>
      {showLiveScoreSummary && <div className="cr-match-live-score" aria-label={match.status === "live" ? "Live score" : "Match score"}>{match.liveScore}</div>}
      <div className="cr-match-sides">
        <div className="cr-team-row">
          <TeamMark code={match.teamA.shortName} />
          <div className="cr-team-name"><strong>{match.teamA.name}</strong><span>{match.teamA.shortName}</span></div>
          <div className="cr-team-score"><b>{firstScore}</b><small>{first ? `${firstOvers} ov` : match.teamAScore ? "" : match.status === "upcoming" || (providerScore && match.teamBScore) ? "Yet to bat" : "—"}</small></div>
        </div>
        <div className="cr-team-row">
          <TeamMark code={match.teamB.shortName} tone="blue" />
          <div className="cr-team-name"><strong>{match.teamB.name}</strong><span>{match.teamB.shortName}</span></div>
          <div className="cr-team-score"><b>{secondScore}</b><small>{second ? `${secondOvers} ov` : match.teamBScore ? "" : match.status === "upcoming" || (providerScore && match.teamAScore) ? "Yet to bat" : "—"}</small></div>
        </div>
      </div>
      <div className="cr-match-bottom">
        <span>{match.venue ? <><MapPin size={13} />{match.venue}</> : <><Clock3 size={13} />{startTime.toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" })}</>}</span>
        <span className="cr-match-summary">{matchSummary} <ArrowUpRight size={14} /></span>
      </div>
    </button>
  );
}
