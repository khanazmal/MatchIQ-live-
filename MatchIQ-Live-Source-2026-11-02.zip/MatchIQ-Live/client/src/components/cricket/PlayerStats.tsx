import { ArrowDownWideNarrow, Search } from "lucide-react";
import { useMemo, useState } from "react";
import type { PlayerStatistic } from "@shared/cricket-samples";

export function PlayerStats({ items, source }: { items: PlayerStatistic[]; source: "database" | "sample" }) {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState<"runs" | "wickets" | "average">("runs");
  const rows = useMemo(() => items
    .filter(player => `${player.playerName} ${player.teamName} ${player.role}`.toLowerCase().includes(search.toLowerCase()))
    .slice()
    .sort((a, b) => sortBy === "runs" ? b.runs - a.runs : sortBy === "wickets" ? b.wickets - a.wickets : b.battingAverage - a.battingAverage), [items, search, sortBy]);

  return (
    <section className="cr-panel">
      <div className="cr-panel-heading">
        <div><span className="cr-eyebrow">PLAYER ROOM</span><h2>Player statistics</h2><p>Runs, wicket tally and efficiency at a glance.</p></div>
        <span className={`cr-source-tag ${source === "sample" ? "is-sample" : ""}`}>{source === "sample" ? "Demo stats" : "SQL · MySQL"}</span>
      </div>
      <div className="cr-table-tools">
        <label className="cr-search"><Search size={15} /><input aria-label="Search players" placeholder="Find a player or team" value={search} onChange={event => setSearch(event.target.value)} /></label>
        <label className="cr-sort"><ArrowDownWideNarrow size={15} /><select aria-label="Sort players" value={sortBy} onChange={event => setSortBy(event.target.value as typeof sortBy)}><option value="runs">Most runs</option><option value="wickets">Most wickets</option><option value="average">Best average</option></select></label>
      </div>
      <div className="cr-table-wrap">
        <table className="cr-table">
          <thead><tr><th>Player</th><th>Team</th><th>Role</th><th>Runs</th><th>Wkts</th><th>Avg</th><th>SR</th><th>Econ</th></tr></thead>
          <tbody>{rows.map((player, index) => <tr key={player.id}>
            <td><div className="cr-player-cell"><span className="cr-player-rank">{String(index + 1).padStart(2, "0")}</span><strong>{player.playerName}</strong></div></td>
            <td><span className="cr-team-code">{player.teamName}</span></td>
            <td className="cr-muted-cell">{player.role.replaceAll("_", " ")}</td>
            <td><b>{player.runs}</b></td><td>{player.wickets}</td>
            <td>{player.battingAverage.toFixed(2)}</td><td>{player.strikeRate.toFixed(1)}</td><td>{player.bowlingEconomy.toFixed(2)}</td>
          </tr>)}</tbody>
        </table>
        {rows.length === 0 && <div className="cr-empty-state">No players match that search.</div>}
      </div>
      <p className="cr-table-footnote">Average = runs ÷ dismissals · Strike rate = runs per 100 balls · Economy = runs per 6 legal balls.</p>
    </section>
  );
}
