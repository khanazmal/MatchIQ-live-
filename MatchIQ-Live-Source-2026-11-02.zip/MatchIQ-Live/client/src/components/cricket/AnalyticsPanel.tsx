import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { PlayerStatistic } from "@shared/cricket-samples";

type Analytics = {
  source: "database" | "sample";
  notice?: string | null;
  totalRuns: number;
  totalWickets: number;
  liveMatches: number;
  topBatters: PlayerStatistic[];
  topBowlers: PlayerStatistic[];
  teamRuns: Array<{ name: string; runs: number }>;
  scoringPhases?: Array<{ phase: string; runs: number }>;
};

const tooltipStyle = { background: "#141b1b", border: "1px solid #293332", borderRadius: 12, color: "#f5f6ee" };

export function AnalyticsPanel({ data }: { data: Analytics }) {
  const batters = data.topBatters.map(player => ({ name: player.playerName.split(" ")[0], runs: player.runs }));
  const bowlers = data.topBowlers.map(player => ({ name: player.playerName.split(" ")[0], wickets: player.wickets }));
  return (
    <div className="cr-analytics-stack">
      <section className="cr-panel">
        <div className="cr-panel-heading"><div><span className="cr-eyebrow">TEAM COMPARISON</span><h2>Runs on the board</h2><p>Total runs grouped by batting team.</p></div><span className={`cr-source-tag ${data.source === "sample" ? "is-sample" : ""}`}>{data.source === "sample" ? "Demo chart" : "SQL aggregate"}</span></div>
        <div className="cr-chart cr-chart-large"><ResponsiveContainer width="100%" height="100%"><BarChart data={data.teamRuns} margin={{ top: 8, right: 8, bottom: 0, left: -16 }}><CartesianGrid stroke="#26302e" strokeDasharray="4 4" vertical={false} /><XAxis dataKey="name" tick={{ fill: "#9da9a2", fontSize: 12 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: "#7e8b84", fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip contentStyle={tooltipStyle} cursor={{ fill: "#ffffff08" }} /><Bar dataKey="runs" name="Runs" fill="#b7f34a" radius={[6, 6, 0, 0]} maxBarSize={42} /></BarChart></ResponsiveContainer></div>
      </section>
      <div className="cr-chart-grid">
        <section className="cr-panel"><div className="cr-panel-heading"><div><span className="cr-eyebrow">BATTER LEADERBOARD</span><h2>Most runs</h2></div></div><div className="cr-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={batters} layout="vertical" margin={{ top: 0, right: 12, bottom: 0, left: 0 }}><CartesianGrid stroke="#26302e" strokeDasharray="4 4" horizontal={false} /><XAxis type="number" tick={{ fill: "#7e8b84", fontSize: 10 }} axisLine={false} tickLine={false} /><YAxis type="category" dataKey="name" width={56} tick={{ fill: "#bec6bf", fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip contentStyle={tooltipStyle} cursor={{ fill: "#ffffff08" }} /><Bar dataKey="runs" name="Runs" fill="#b7f34a" radius={[0, 5, 5, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div></section>
        <section className="cr-panel"><div className="cr-panel-heading"><div><span className="cr-eyebrow">BOWLER LEADERBOARD</span><h2>Most wickets</h2></div></div><div className="cr-chart"><ResponsiveContainer width="100%" height="100%"><BarChart data={bowlers} layout="vertical" margin={{ top: 0, right: 12, bottom: 0, left: 0 }}><CartesianGrid stroke="#26302e" strokeDasharray="4 4" horizontal={false} /><XAxis type="number" tick={{ fill: "#7e8b84", fontSize: 10 }} axisLine={false} tickLine={false} /><YAxis type="category" dataKey="name" width={56} tick={{ fill: "#bec6bf", fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip contentStyle={tooltipStyle} cursor={{ fill: "#ffffff08" }} /><Bar dataKey="wickets" name="Wickets" fill="#64c9cb" radius={[0, 5, 5, 0]} maxBarSize={16} /></BarChart></ResponsiveContainer></div></section>
      </div>
      {data.notice && <p className="cr-inline-note">{data.notice}</p>}
    </div>
  );
}
