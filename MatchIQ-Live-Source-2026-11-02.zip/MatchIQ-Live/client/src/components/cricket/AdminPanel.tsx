import { Database, ShieldCheck } from "lucide-react";
import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { TeamsManager } from "./admin/TeamsManager";
import { PlayersManager } from "./admin/PlayersManager";
import { MatchesManager } from "./admin/MatchesManager";
import { ScorebookManager } from "./admin/ScorebookManager";

type AdminTab = "teams" | "players" | "matches" | "scorebook";

export function AdminPanel() {
  const [active, setActive] = useState<AdminTab>("matches");
  const utils = trpc.useUtils();
  const refreshData = async () => {
    await Promise.all([
      utils.cricket.admin.teams.list.invalidate(),
      utils.cricket.admin.players.list.invalidate(),
      utils.cricket.admin.matches.list.invalidate(),
      utils.cricket.admin.innings.list.invalidate(),
      utils.cricket.admin.battingScorecards.list.invalidate(),
      utils.cricket.admin.bowlingScorecards.list.invalidate(),
      utils.cricket.admin.partnerships.list.invalidate(),
      utils.cricket.matches.list.invalidate(),
      utils.cricket.players.statistics.invalidate(),
      utils.cricket.analytics.overview.invalidate(),
    ]);
  };
  const tabs: Array<{ id: AdminTab; label: string }> = [
    { id: "matches", label: "Matches" },
    { id: "teams", label: "Teams" },
    { id: "players", label: "Players" },
    { id: "scorebook", label: "Innings & scorecards" },
  ];

  return <section className="cr-panel cr-admin-panel">
    <div className="cr-admin-heading"><div className="cr-admin-icon"><ShieldCheck size={18} /></div><div><span className="cr-eyebrow">ADMIN ONLY · WRITES ARE PROTECTED</span><h2>Cricket data manager</h2><p>Saved records only. Sample fixtures are fictional and read-only.</p></div><span className="cr-admin-db"><Database size={14} /> MySQL</span></div>
    <div className="cr-admin-tabs" role="tablist" aria-label="Cricket record type">{tabs.map(tab => <button key={tab.id} role="tab" aria-selected={active === tab.id} type="button" className={active === tab.id ? "is-active" : ""} onClick={() => setActive(tab.id)}>{tab.label}</button>)}</div>
    <div className="cr-admin-body">
      {active === "matches" && <MatchesManager onSaved={refreshData} />}
      {active === "teams" && <TeamsManager onSaved={refreshData} />}
      {active === "players" && <PlayersManager onSaved={refreshData} />}
      {active === "scorebook" && <ScorebookManager onSaved={refreshData} />}
    </div>
  </section>;
}
