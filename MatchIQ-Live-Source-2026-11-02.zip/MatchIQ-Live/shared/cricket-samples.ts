export type CricketTeamCard = {
  id: number;
  name: string;
  shortName: string;
  country?: string | null;
};

export type BattingLine = {
  id: number;
  playerName: string;
  battingPosition: number;
  runs: number;
  ballsFaced: number;
  fours: number;
  sixes: number;
  dismissal: string | null;
  isNotOut: boolean;
};

export type BowlingLine = {
  id: number;
  playerName: string;
  legalBalls: number;
  maidens: number;
  runsConceded: number;
  wickets: number;
  wides: number;
  noBalls: number;
};

export type PartnershipLine = {
  wicketNumber: number;
  batterOne: string;
  batterTwo: string;
  runs: number;
  balls: number;
};

export type CricketInningsCard = {
  id: number;
  inningsNumber: number;
  battingTeamId: number;
  bowlingTeamId: number;
  totalRuns: number;
  wickets: number;
  legalBalls: number;
  extras: number;
  target: number | null;
  status: "upcoming" | "in_progress" | "completed";
  declared: boolean;
  batting: BattingLine[];
  bowling: BowlingLine[];
  partnerships: PartnershipLine[];
};

export type CricketMatchCard = {
  id: number;
  providerMatchId?: string;
  title: string;
  format: "T20" | "ODI" | "Test" | "T10" | "Other";
  competition: string | null;
  venue: string | null;
  scheduledAt: string;
  status: "upcoming" | "live" | "completed" | "abandoned";
  teamA: CricketTeamCard;
  teamB: CricketTeamCard;
  currentInnings: number | null;
  result: string | null;
  summary: string | null;
  liveScore?: string | null;
  teamAScore?: string | null;
  teamBScore?: string | null;
  dataSource: "sample" | "manual" | "cricbuzz" | "cricketliveapi" | "other";
  innings: CricketInningsCard[];
};

export type PlayerStatistic = {
  id: number;
  playerName: string;
  teamName: string;
  role: string;
  runs: number;
  wickets: number;
  battingAverage: number;
  strikeRate: number;
  bowlingEconomy: number;
};

const sampleTeams = {
  harbour: { id: -1, name: "Harbour Strikers", shortName: "HBS", country: "Sample League" },
  hilltop: { id: -2, name: "Hilltop Hawks", shortName: "HTH", country: "Sample League" },
  river: { id: -3, name: "River City Royals", shortName: "RCR", country: "Sample League" },
  mountain: { id: -4, name: "Mountain Mavericks", shortName: "MTM", country: "Sample League" },
  coastal: { id: -5, name: "Coastal Comets", shortName: "CLC", country: "Sample League" },
  capital: { id: -6, name: "Capital Cyclones", shortName: "CAC", country: "Sample League" },
};

export const sampleMatches: CricketMatchCard[] = [
  {
    id: -1001,
    title: "Match 12 · Evening fixture",
    format: "T20",
    competition: "MatchIQ Demo League",
    venue: "Harbour Arena",
    scheduledAt: new Date(Date.now() - 90 * 60 * 1000).toISOString(),
    status: "live",
    teamA: sampleTeams.harbour,
    teamB: sampleTeams.hilltop,
    currentInnings: 2,
    result: null,
    summary: "Harbour Strikers are chasing 187 in a fictional sample fixture.",
    dataSource: "sample",
    innings: [
      {
        id: -2001,
        inningsNumber: 1,
        battingTeamId: sampleTeams.hilltop.id,
        bowlingTeamId: sampleTeams.harbour.id,
        totalRuns: 186,
        wickets: 6,
        legalBalls: 120,
        extras: 9,
        target: null,
        status: "completed",
        declared: false,
        batting: [
          { id: -11, playerName: "Kabir Rao", battingPosition: 1, runs: 72, ballsFaced: 43, fours: 7, sixes: 3, dismissal: "c Mehta b Khan", isNotOut: false },
          { id: -12, playerName: "Dev Malhotra", battingPosition: 2, runs: 41, ballsFaced: 29, fours: 4, sixes: 1, dismissal: "b Sen", isNotOut: false },
          { id: -13, playerName: "Rohan Das", battingPosition: 3, runs: 27, ballsFaced: 18, fours: 2, sixes: 1, dismissal: "not out", isNotOut: true },
        ],
        bowling: [
          { id: -21, playerName: "Arjun Khan", legalBalls: 24, maidens: 0, runsConceded: 35, wickets: 2, wides: 2, noBalls: 0 },
          { id: -22, playerName: "Samar Sen", legalBalls: 24, maidens: 0, runsConceded: 31, wickets: 1, wides: 1, noBalls: 0 },
        ],
        partnerships: [
          { wicketNumber: 1, batterOne: "Kabir Rao", batterTwo: "Dev Malhotra", runs: 63, balls: 42 },
          { wicketNumber: 2, batterOne: "Kabir Rao", batterTwo: "Rohan Das", runs: 54, balls: 35 },
        ],
      },
      {
        id: -2002,
        inningsNumber: 2,
        battingTeamId: sampleTeams.harbour.id,
        bowlingTeamId: sampleTeams.hilltop.id,
        totalRuns: 148,
        wickets: 4,
        legalBalls: 104,
        extras: 7,
        target: 187,
        status: "in_progress",
        declared: false,
        batting: [
          { id: -31, playerName: "Aarav Mehta", battingPosition: 1, runs: 48, ballsFaced: 32, fours: 5, sixes: 2, dismissal: "not out", isNotOut: true },
          { id: -32, playerName: "Ishan Kaur", battingPosition: 2, runs: 23, ballsFaced: 17, fours: 2, sixes: 1, dismissal: "c Rao b Patel", isNotOut: false },
          { id: -33, playerName: "Nikhil Roy", battingPosition: 3, runs: 36, ballsFaced: 22, fours: 3, sixes: 2, dismissal: "c Das b Rao", isNotOut: false },
          { id: -34, playerName: "Samar Sen", battingPosition: 4, runs: 19, ballsFaced: 13, fours: 1, sixes: 1, dismissal: "lbw b Patel", isNotOut: false },
          { id: -35, playerName: "Dev Shah", battingPosition: 5, runs: 12, ballsFaced: 9, fours: 1, sixes: 0, dismissal: "not out", isNotOut: true },
        ],
        bowling: [
          { id: -14, playerName: "Kabir Rao", legalBalls: 18, maidens: 0, runsConceded: 24, wickets: 1, wides: 1, noBalls: 0 },
          { id: -15, playerName: "Dev Malhotra", legalBalls: 18, maidens: 0, runsConceded: 26, wickets: 2, wides: 2, noBalls: 0 },
        ],
        partnerships: [
          { wicketNumber: 1, batterOne: "Aarav Mehta", batterTwo: "Ishan Kaur", runs: 37, balls: 26 },
          { wicketNumber: 2, batterOne: "Aarav Mehta", batterTwo: "Nikhil Roy", runs: 49, balls: 32 },
          { wicketNumber: 4, batterOne: "Aarav Mehta", batterTwo: "Dev Shah", runs: 21, balls: 11 },
        ],
      },
    ],
  },
  {
    id: -1002,
    title: "Match 13 · Tomorrow's spotlight",
    format: "T20",
    competition: "MatchIQ Demo League",
    venue: "Riverside Ground",
    scheduledAt: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
    status: "upcoming",
    teamA: sampleTeams.river,
    teamB: sampleTeams.mountain,
    currentInnings: null,
    result: null,
    summary: "A fictional sample fixture scheduled for later today.",
    dataSource: "sample",
    innings: [],
  },
  {
    id: -1003,
    title: "Match 11 · Final result",
    format: "ODI",
    competition: "MatchIQ Demo League",
    venue: "Coastal Oval",
    scheduledAt: new Date(Date.now() - 25 * 60 * 60 * 1000).toISOString(),
    status: "completed",
    teamA: sampleTeams.coastal,
    teamB: sampleTeams.capital,
    currentInnings: 2,
    result: "Coastal Comets won by 18 runs",
    summary: "A fictional sample result. Coastal Comets defended 264 after a steady middle overs partnership.",
    dataSource: "sample",
    innings: [
      {
        id: -2003,
        inningsNumber: 1,
        battingTeamId: sampleTeams.coastal.id,
        bowlingTeamId: sampleTeams.capital.id,
        totalRuns: 264,
        wickets: 8,
        legalBalls: 300,
        extras: 12,
        target: null,
        status: "completed",
        declared: false,
        batting: [
          { id: -41, playerName: "Neel Joshi", battingPosition: 1, runs: 91, ballsFaced: 104, fours: 8, sixes: 1, dismissal: "c Kumar b Verma", isNotOut: false },
          { id: -42, playerName: "Tara Pillai", battingPosition: 2, runs: 58, ballsFaced: 66, fours: 5, sixes: 0, dismissal: "b Sethi", isNotOut: false },
        ],
        bowling: [
          { id: -43, playerName: "Aman Verma", legalBalls: 60, maidens: 1, runsConceded: 48, wickets: 2, wides: 3, noBalls: 0 },
          { id: -44, playerName: "Ira Sethi", legalBalls: 54, maidens: 0, runsConceded: 52, wickets: 2, wides: 1, noBalls: 1 },
        ],
        partnerships: [{ wicketNumber: 1, batterOne: "Neel Joshi", batterTwo: "Tara Pillai", runs: 112, balls: 128 }],
      },
      {
        id: -2004,
        inningsNumber: 2,
        battingTeamId: sampleTeams.capital.id,
        bowlingTeamId: sampleTeams.coastal.id,
        totalRuns: 246,
        wickets: 9,
        legalBalls: 300,
        extras: 10,
        target: 265,
        status: "completed",
        declared: false,
        batting: [
          { id: -45, playerName: "Mira Kumar", battingPosition: 1, runs: 76, ballsFaced: 82, fours: 7, sixes: 1, dismissal: "c Pillai b Ali", isNotOut: false },
          { id: -46, playerName: "Yash Sethi", battingPosition: 2, runs: 64, ballsFaced: 72, fours: 4, sixes: 2, dismissal: "b Joshi", isNotOut: false },
        ],
        bowling: [
          { id: -47, playerName: "Farah Ali", legalBalls: 60, maidens: 0, runsConceded: 43, wickets: 3, wides: 2, noBalls: 0 },
          { id: -48, playerName: "Neel Joshi", legalBalls: 48, maidens: 0, runsConceded: 39, wickets: 2, wides: 1, noBalls: 0 },
        ],
        partnerships: [{ wicketNumber: 1, batterOne: "Mira Kumar", batterTwo: "Yash Sethi", runs: 99, balls: 110 }],
      },
    ],
  },
];

export const samplePlayerStatistics: PlayerStatistic[] = [
  { id: -31, playerName: "Aarav Mehta", teamName: "HBS", role: "batter", runs: 486, wickets: 1, battingAverage: 44.18, strikeRate: 137.28, bowlingEconomy: 8.4 },
  { id: -11, playerName: "Kabir Rao", teamName: "HTH", role: "all_rounder", runs: 421, wickets: 12, battingAverage: 35.08, strikeRate: 129.54, bowlingEconomy: 7.92 },
  { id: -41, playerName: "Neel Joshi", teamName: "CLC", role: "batter", runs: 398, wickets: 2, battingAverage: 49.75, strikeRate: 91.28, bowlingEconomy: 5.88 },
  { id: -21, playerName: "Arjun Khan", teamName: "HBS", role: "bowler", runs: 68, wickets: 18, battingAverage: 13.6, strikeRate: 104.61, bowlingEconomy: 7.16 },
  { id: -22, playerName: "Samar Sen", teamName: "HBS", role: "all_rounder", runs: 178, wickets: 14, battingAverage: 25.42, strikeRate: 121.08, bowlingEconomy: 7.44 },
];

export const sampleAnalytics = {
  source: "sample" as const,
  notice: "Sample figures for layout/testing only — analytics are sample data, not live CricketLiveAPI statistics.",
  totalRuns: 1596,
  totalWickets: 45,
  liveMatches: 1,
  topBatters: samplePlayerStatistics.slice().sort((a, b) => b.runs - a.runs).slice(0, 5),
  topBowlers: samplePlayerStatistics.slice().sort((a, b) => b.wickets - a.wickets).slice(0, 5),
  teamRuns: [{ name: "HBS", runs: 334 }, { name: "HTH", runs: 186 }, { name: "CLC", runs: 264 }, { name: "CAC", runs: 246 }],
  scoringPhases: [
    { phase: "Overs 1–6", runs: 42 },
    { phase: "Overs 7–12", runs: 51 },
    { phase: "Overs 13–16", runs: 39 },
    { phase: "Overs 17–20", runs: 54 },
  ],
};
