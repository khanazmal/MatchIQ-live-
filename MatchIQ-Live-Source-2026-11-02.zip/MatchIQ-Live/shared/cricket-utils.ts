export function formatOvers(legalBalls: number): string {
  const safeBalls = Math.max(0, Math.floor(legalBalls));
  return `${Math.floor(safeBalls / 6)}.${safeBalls % 6}`;
}

export function battingAverage(runs: number, dismissals: number): number {
  return dismissals > 0 ? runs / dismissals : runs;
}

export function battingStrikeRate(runs: number, ballsFaced: number): number {
  return ballsFaced > 0 ? (runs / ballsFaced) * 100 : 0;
}

export function bowlingEconomy(runsConceded: number, legalBalls: number): number {
  return legalBalls > 0 ? (runsConceded / legalBalls) * 6 : 0;
}

export function roundToTwo(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}
