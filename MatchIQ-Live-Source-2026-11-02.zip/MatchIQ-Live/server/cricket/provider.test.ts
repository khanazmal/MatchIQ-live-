import { describe, expect, it, vi } from "vitest";
import { computeRateLimitBackoffMs, normalizeCricketLiveResponse, parseRetryAfterMs } from "./provider";

describe("CricketLiveAPI response normalization", () => {
  it("accepts the observed successful empty live feed", () => {
    expect(normalizeCricketLiveResponse({ success: true, type: "live", count: 0, data: [] })).toEqual([]);
  });

  it("normalizes the provider's published data.matches example", () => {
    const [match] = normalizeCricketLiveResponse({
      status: "success",
      data: {
        matches: [{
          match_id: 92411,
          teams: "India vs Australia",
          format: "T20",
          status: "live",
          score: "187/3 (18.4 ov)",
          venue: "Wankhede Stadium",
        }],
      },
    }, new Date("2026-10-16T10:00:00.000Z"));

    expect(match).toMatchObject({
      providerMatchId: "92411",
      title: "India v Australia",
      format: "T20",
      status: "live",
      liveScore: "187/3 (18.4 ov)",
      venue: "Wankhede Stadium",
      dataSource: "cricketliveapi",
    });
    expect(match.teamA.name).toBe("India");
    expect(match.teamB.name).toBe("Australia");
    expect(match.id).toBeLessThan(-1_000_000_000);
  });

  it("normalizes a direct data array with alternate team fields", () => {
    const [match] = normalizeCricketLiveResponse({
      success: true,
      type: "live",
      count: 1,
      data: [{ match_id: "match-1", team_a: "New Zealand", team_b: "Pakistan", score: "45/1 (5.2 ov)" }],
    });
    expect(match.teamA.name).toBe("New Zealand");
    expect(match.teamB.name).toBe("Pakistan");
    expect(match.liveScore).toBe("45/1 (5.2 ov)");
  });

  it("maps the authenticated nested Preview/Toss payload as upcoming, not live", () => {
    const [match] = normalizeCricketLiveResponse({
      success: true,
      type: "live",
      count: 1,
      data: [{
        match_id: 175051,
        series_name: "World Championship of Legends 2026",
        match_desc: "Semi Final 1",
        title: "World Championship of Legends 2026 - Semi Final 1",
        format: "T20",
        date: "Oct 16, 11:30 GMT",
        venue: "Sharjah Cricket Stadium, Sharjah",
        status_detail: "South Africa Champions opt to bowl",
        state: "Toss",
        status: "Preview",
        first_team: { id: 2030, name: "ENGCH", full_name: "England Champions", score: "", innings: [] },
        second_team: { id: 2014, name: "SACH", full_name: "South Africa Champions", score: "", innings: [] },
      }],
    }, new Date("2026-10-16T11:07:00.000Z"));

    expect(match).toMatchObject({
      teamA: { name: "England Champions", shortName: "ENGCH" },
      teamB: { name: "South Africa Champions", shortName: "SACH" },
      competition: "World Championship of Legends 2026",
      status: "upcoming",
      scheduledAt: "2026-10-16T11:30:00.000Z",
      summary: "South Africa Champions opt to bowl",
      liveScore: null,
    });
  });

  it("prefers structured live innings over the provider's incomplete display score", () => {
    const [match] = normalizeCricketLiveResponse({
      success: true,
      type: "live",
      count: 1,
      data: [{
        match_id: 175051,
        format: "T20",
        state: "In Progress",
        status: "In Progress",
        first_team: {
          name: "ENGCH",
          full_name: "England Champions",
          score: "3/ (1.1 ov)",
          innings: [{ runs: "3", wickets: "0", overs: "1.1" }],
        },
        second_team: {
          name: "SACH",
          full_name: "South Africa Champions",
          score: "",
          innings: [],
        },
      }],
    });
    expect(match.status).toBe("live");
    expect(match.liveScore).toBe("England Champions 3/0 (1.1 ov)");
    expect(match.teamAScore).toBe("3/0 (1.1 ov)");
    expect(match.teamBScore).toBeNull();
  });

  it("normalizes structured score objects and innings arrays", () => {
    const [match] = normalizeCricketLiveResponse({
      success: true,
      data: [{
        match_id: "match-structured",
        teams: ["South Africa", "Sri Lanka"],
        score: {
          innings: [
            { runs: 178, wickets: 4, overs: "18.2" },
            { runs: 169, wickets: 8, overs: "20.0 ov" },
          ],
        },
      }],
    });
    expect(match.liveScore).toBe("178/4 (18.2 ov) · 169/8 (20.0 ov)");
  });

  it("omits nonstandard overs values while keeping valid live runs and wickets", () => {
    const [match] = normalizeCricketLiveResponse({
      success: true,
      data: [{
        match_id: "match-invalid-overs",
        status: "In Progress",
        first_team: {
          full_name: "England Champions",
          score: "10/0 (1.6 ov)",
          innings: [{ runs: "10", wickets: "0", overs: "1.6" }],
        },
        second_team: { full_name: "South Africa Champions", score: "", innings: [] },
      }],
    });
    expect(match.teamAScore).toBe("10/0");
    expect(match.liveScore).toBe("England Champions 10/0");
  });

  it("rejects failed or unsupported response envelopes", () => {
    expect(() => normalizeCricketLiveResponse({ success: false, data: [] })).toThrow(/successful response envelope/);
    expect(() => normalizeCricketLiveResponse({ success: true, data: {} })).toThrow(/unsupported live-match response shape/);
  });

  it("rejects a non-empty feed entry without the documented identity or team names", () => {
    expect(() => normalizeCricketLiveResponse({
      success: true,
      data: [{ match_id: 1, teams: "Team A" }],
    })).toThrow(/missing its match ID or two team names/);
  });
});

describe("CricketLiveAPI rate-limit handling", () => {
  it("parses Retry-After delta-seconds and HTTP dates, rejecting invalid or expired values", () => {
    const now = Date.parse("2026-10-17T10:00:00.000Z");
    expect(parseRetryAfterMs("3600", now)).toBe(60 * 60_000);
    expect(parseRetryAfterMs(new Date(now + 60 * 60_000).toUTCString(), now)).toBe(60 * 60_000);
    expect(parseRetryAfterMs("not-a-date", now)).toBeNull();
    expect(parseRetryAfterMs(new Date(now - 1000).toUTCString(), now)).toBeNull();
  });

  it("uses bounded exponential fallback and never retries earlier than a valid Retry-After", () => {
    expect(computeRateLimitBackoffMs(null, 1)).toBe(30 * 60_000);
    expect(computeRateLimitBackoffMs(null, 2)).toBe(60 * 60_000);
    expect(computeRateLimitBackoffMs(null, 99)).toBe(24 * 60 * 60_000);
    expect(computeRateLimitBackoffMs(5 * 60_000, 1)).toBe(30 * 60_000);
    expect(computeRateLimitBackoffMs(2 * 60 * 60_000, 1)).toBe(2 * 60 * 60_000);
  });

  it("caches a 429 through Retry-After and suppresses provider calls until it expires", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-10-17T10:00:00.000Z"));
    vi.stubEnv("CRICKETLIVEAPI_TOKEN", "unit-test-token");
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(new Response(null, { status: 429, headers: { "Retry-After": "3600" } }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ success: true, type: "live", count: 0, data: [] }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      }));
    vi.stubGlobal("fetch", fetchMock);
    vi.resetModules();

    try {
      const { getCricketLiveFeed } = await import("./provider");
      const firstResult = await getCricketLiveFeed();
      expect(firstResult.feed.status).toBe("error");
      expect(fetchMock).toHaveBeenCalledTimes(1);
      expect((await getCricketLiveFeed()).feed.fetchedAt).toBe(firstResult.feed.fetchedAt);

      await vi.advanceTimersByTimeAsync(30 * 60_000 + 1);
      await getCricketLiveFeed();
      expect(fetchMock).toHaveBeenCalledTimes(1);

      await vi.advanceTimersByTimeAsync(30 * 60_000);
      expect((await getCricketLiveFeed()).feed.status).toBe("empty");
      expect(fetchMock).toHaveBeenCalledTimes(2);
    } finally {
      vi.useRealTimers();
      vi.unstubAllGlobals();
      vi.unstubAllEnvs();
      vi.resetModules();
    }
  });

  it("backs off exponentially without Retry-After and resets its streak after a non-429 response", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-10-17T10:00:00.000Z"));
    vi.stubEnv("CRICKETLIVEAPI_TOKEN", "unit-test-token");
    const rateLimited = (retryAfter?: string) => new Response(null, {
      status: 429,
      headers: retryAfter ? { "Retry-After": retryAfter } : undefined,
    });
    const success = () => new Response(JSON.stringify({ success: true, type: "live", count: 0, data: [] }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(rateLimited())
      .mockResolvedValueOnce(rateLimited("invalid"))
      .mockResolvedValueOnce(success())
      .mockResolvedValueOnce(rateLimited())
      .mockResolvedValueOnce(success());
    vi.stubGlobal("fetch", fetchMock);
    vi.resetModules();

    try {
      const { getCricketLiveFeed } = await import("./provider");
      expect((await getCricketLiveFeed()).feed.status).toBe("error");
      expect(fetchMock).toHaveBeenCalledTimes(1);

      await vi.advanceTimersByTimeAsync(30 * 60_000 + 1);
      expect((await getCricketLiveFeed()).feed.status).toBe("error");
      expect(fetchMock).toHaveBeenCalledTimes(2);

      await vi.advanceTimersByTimeAsync(60 * 60_000 + 1);
      expect((await getCricketLiveFeed()).feed.status).toBe("empty");
      expect(fetchMock).toHaveBeenCalledTimes(3);

      await vi.advanceTimersByTimeAsync(30 * 60_000 + 1);
      expect((await getCricketLiveFeed()).feed.status).toBe("error");
      expect(fetchMock).toHaveBeenCalledTimes(4);

      await vi.advanceTimersByTimeAsync(30 * 60_000 + 1);
      expect((await getCricketLiveFeed()).feed.status).toBe("empty");
      expect(fetchMock).toHaveBeenCalledTimes(5);
    } finally {
      vi.useRealTimers();
      vi.unstubAllGlobals();
      vi.unstubAllEnvs();
      vi.resetModules();
    }
  });
});
