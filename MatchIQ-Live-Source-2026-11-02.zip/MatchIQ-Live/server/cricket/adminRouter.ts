import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { adminProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import {
  battingScorecards,
  bowlingScorecards,
  innings,
  matches,
  partnerships,
  players,
  teams,
} from "../../drizzle/schema";
import { desc, eq } from "drizzle-orm";

async function requireDb() {
  const db = await getDb();
  if (!db) {
    throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Database is not configured. Set DATABASE_URL first." });
  }
  return db;
}

const idInput = z.object({ id: z.number().int().positive() });
const teamInput = z.object({
  name: z.string().trim().min(2).max(120),
  shortName: z.string().trim().min(2).max(12),
  country: z.string().trim().min(2).max(80),
  logoUrl: z.string().trim().url().max(500).or(z.literal("")).nullable().optional(),
});
const playerInput = z.object({
  fullName: z.string().trim().min(2).max(160),
  teamId: z.number().int().positive().nullable().optional(),
  role: z.enum(["batter", "bowler", "all_rounder", "wicket_keeper"]),
  battingStyle: z.string().trim().max(50).nullable().optional(),
  bowlingStyle: z.string().trim().max(80).nullable().optional(),
  country: z.string().trim().max(80).nullable().optional(),
});
const matchFields = z.object({
  title: z.string().trim().min(3).max(180),
  format: z.enum(["T20", "ODI", "Test", "T10", "Other"]),
  competition: z.string().trim().max(160).nullable().optional(),
  venue: z.string().trim().max(180).nullable().optional(),
  scheduledAt: z.coerce.date(),
  status: z.enum(["upcoming", "live", "completed", "abandoned"]).default("upcoming"),
  teamAId: z.number().int().positive(),
  teamBId: z.number().int().positive(),
  currentInnings: z.number().int().min(1).max(4).nullable().optional(),
  winnerTeamId: z.number().int().positive().nullable().optional(),
  result: z.string().trim().max(2000).nullable().optional(),
  summary: z.string().trim().max(5000).nullable().optional(),
});
const matchInput = matchFields.refine(value => value.teamAId !== value.teamBId, { message: "A team cannot play against itself", path: ["teamBId"] });
const matchUpdateInput = matchFields.partial().refine(value => value.teamAId === undefined || value.teamBId === undefined || value.teamAId !== value.teamBId, { message: "A team cannot play against itself", path: ["teamBId"] });
const inningsFields = z.object({
  matchId: z.number().int().positive(),
  inningsNumber: z.number().int().min(1).max(4),
  battingTeamId: z.number().int().positive(),
  bowlingTeamId: z.number().int().positive(),
  totalRuns: z.number().int().min(0).default(0),
  wickets: z.number().int().min(0).max(10).default(0),
  legalBalls: z.number().int().min(0).default(0),
  extras: z.number().int().min(0).default(0),
  target: z.number().int().min(1).nullable().optional(),
  status: z.enum(["upcoming", "in_progress", "completed"]).default("upcoming"),
  declared: z.boolean().default(false),
});
const inningsInput = inningsFields.refine(value => value.battingTeamId !== value.bowlingTeamId, { message: "Batting and bowling teams must differ", path: ["bowlingTeamId"] });
const inningsUpdateInput = inningsFields.partial().refine(value => value.battingTeamId === undefined || value.bowlingTeamId === undefined || value.battingTeamId !== value.bowlingTeamId, { message: "Batting and bowling teams must differ", path: ["bowlingTeamId"] });
const battingInput = z.object({
  inningsId: z.number().int().positive(),
  playerId: z.number().int().positive(),
  battingPosition: z.number().int().min(1).max(11),
  runs: z.number().int().min(0).default(0),
  ballsFaced: z.number().int().min(0).default(0),
  fours: z.number().int().min(0).default(0),
  sixes: z.number().int().min(0).default(0),
  dismissal: z.string().trim().max(220).nullable().optional(),
  isNotOut: z.boolean().default(false),
});
const bowlingInput = z.object({
  inningsId: z.number().int().positive(),
  playerId: z.number().int().positive(),
  legalBalls: z.number().int().min(0).default(0),
  maidens: z.number().int().min(0).default(0),
  runsConceded: z.number().int().min(0).default(0),
  wickets: z.number().int().min(0).max(10).default(0),
  wides: z.number().int().min(0).default(0),
  noBalls: z.number().int().min(0).default(0),
});
const partnershipFields = z.object({
  inningsId: z.number().int().positive(),
  wicketNumber: z.number().int().min(1).max(10),
  batterOneId: z.number().int().positive(),
  batterTwoId: z.number().int().positive(),
  runs: z.number().int().min(0).default(0),
  balls: z.number().int().min(0).default(0),
});
const partnershipCreateInput = partnershipFields.refine(value => value.batterOneId !== value.batterTwoId, { message: "A partnership requires two different batters", path: ["batterTwoId"] });
const partnershipUpdateInput = partnershipFields.partial().refine(value => value.batterOneId === undefined || value.batterTwoId === undefined || value.batterOneId !== value.batterTwoId, { message: "A partnership requires two different batters", path: ["batterTwoId"] });

async function requireAffectedRows(result: unknown, existsAfter?: () => Promise<boolean>) {
  const header = Array.isArray(result) ? result[0] : result;
  const affectedRows = header && typeof header === "object" && "affectedRows" in header
    ? Number(header.affectedRows)
    : 0;
  if (!affectedRows && !(existsAfter && await existsAfter())) throw new TRPCError({ code: "NOT_FOUND", message: "Record not found." });
  return { success: true as const };
}

type CricketDatabase = NonNullable<Awaited<ReturnType<typeof getDb>>>;

async function assertInningsTeams(
  db: CricketDatabase,
  matchId: number,
  battingTeamId: number,
  bowlingTeamId: number,
) {
  const [match] = await db.select({ teamAId: matches.teamAId, teamBId: matches.teamBId })
    .from(matches).where(eq(matches.id, matchId)).limit(1);
  if (!match) throw new TRPCError({ code: "NOT_FOUND", message: "Match not found." });
  const matchTeams = new Set([match.teamAId, match.teamBId]);
  if (battingTeamId === bowlingTeamId || !matchTeams.has(battingTeamId) || !matchTeams.has(bowlingTeamId)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "The batting and bowling teams must be the two teams assigned to this match." });
  }
}

export const adminCricketRouter = router({
  teams: router({
    list: adminProcedure.query(async () => {
      const db = await requireDb();
      return db.select().from(teams).orderBy(teams.name);
    }),
    create: adminProcedure.input(teamInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const [created] = await db.insert(teams).values({ ...input, logoUrl: input.logoUrl || null }).$returningId();
      return { id: created.id };
    }),
    update: adminProcedure.input(z.object({ id: idInput.shape.id, data: teamInput.partial() })).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.update(teams).set(input.data).where(eq(teams.id, input.id));
      return requireAffectedRows(result, async () => Boolean((await db.select({ id: teams.id }).from(teams).where(eq(teams.id, input.id)).limit(1))[0]));
    }),
    delete: adminProcedure.input(idInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.delete(teams).where(eq(teams.id, input.id));
      return requireAffectedRows(result);
    }),
  }),
  players: router({
    list: adminProcedure.query(async () => {
      const db = await requireDb();
      return db.select().from(players).orderBy(players.fullName);
    }),
    create: adminProcedure.input(playerInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const [created] = await db.insert(players).values(input).$returningId();
      return { id: created.id };
    }),
    update: adminProcedure.input(z.object({ id: idInput.shape.id, data: playerInput.partial() })).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.update(players).set(input.data).where(eq(players.id, input.id));
      return requireAffectedRows(result, async () => Boolean((await db.select({ id: players.id }).from(players).where(eq(players.id, input.id)).limit(1))[0]));
    }),
    delete: adminProcedure.input(idInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.delete(players).where(eq(players.id, input.id));
      return requireAffectedRows(result);
    }),
  }),
  matches: router({
    list: adminProcedure.query(async () => {
      const db = await requireDb();
      return db.select().from(matches).orderBy(desc(matches.scheduledAt));
    }),
    create: adminProcedure.input(matchInput).mutation(async ({ input, ctx }) => {
      const db = await requireDb();
      const [created] = await db.insert(matches).values({ ...input, dataSource: "manual", createdBy: ctx.user.id }).$returningId();
      return { id: created.id };
    }),
    update: adminProcedure.input(z.object({ id: idInput.shape.id, data: matchUpdateInput })).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.update(matches).set(input.data).where(eq(matches.id, input.id));
      return requireAffectedRows(result, async () => Boolean((await db.select({ id: matches.id }).from(matches).where(eq(matches.id, input.id)).limit(1))[0]));
    }),
    delete: adminProcedure.input(idInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.delete(matches).where(eq(matches.id, input.id));
      return requireAffectedRows(result);
    }),
  }),
  innings: router({
    list: adminProcedure.input(z.object({ matchId: idInput.shape.id.optional() }).optional()).query(async ({ input }) => {
      const db = await requireDb();
      if (input?.matchId) return db.select().from(innings).where(eq(innings.matchId, input.matchId)).orderBy(innings.inningsNumber);
      return db.select().from(innings).orderBy(desc(innings.createdAt));
    }),
    create: adminProcedure.input(inningsInput).mutation(async ({ input }) => {
      const db = await requireDb();
      await assertInningsTeams(db, input.matchId, input.battingTeamId, input.bowlingTeamId);
      const [created] = await db.insert(innings).values(input).$returningId();
      return { id: created.id };
    }),
    update: adminProcedure.input(z.object({ id: idInput.shape.id, data: inningsUpdateInput })).mutation(async ({ input }) => {
      const db = await requireDb();
      const [current] = await db.select().from(innings).where(eq(innings.id, input.id)).limit(1);
      if (!current) throw new TRPCError({ code: "NOT_FOUND", message: "Innings record not found." });
      await assertInningsTeams(
        db,
        input.data.matchId ?? current.matchId,
        input.data.battingTeamId ?? current.battingTeamId,
        input.data.bowlingTeamId ?? current.bowlingTeamId,
      );
      const result = await db.update(innings).set(input.data).where(eq(innings.id, input.id));
      return requireAffectedRows(result, async () => Boolean((await db.select({ id: innings.id }).from(innings).where(eq(innings.id, input.id)).limit(1))[0]));
    }),
    delete: adminProcedure.input(idInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.delete(innings).where(eq(innings.id, input.id));
      return requireAffectedRows(result);
    }),
  }),
  battingScorecards: router({
    list: adminProcedure.input(z.object({ inningsId: idInput.shape.id.optional() }).optional()).query(async ({ input }) => {
      const db = await requireDb();
      if (input?.inningsId) return db.select().from(battingScorecards).where(eq(battingScorecards.inningsId, input.inningsId)).orderBy(battingScorecards.battingPosition);
      return db.select().from(battingScorecards).orderBy(desc(battingScorecards.createdAt));
    }),
    create: adminProcedure.input(battingInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const [created] = await db.insert(battingScorecards).values(input).$returningId();
      return { id: created.id };
    }),
    update: adminProcedure.input(z.object({ id: idInput.shape.id, data: battingInput.partial() })).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.update(battingScorecards).set(input.data).where(eq(battingScorecards.id, input.id));
      return requireAffectedRows(result, async () => Boolean((await db.select({ id: battingScorecards.id }).from(battingScorecards).where(eq(battingScorecards.id, input.id)).limit(1))[0]));
    }),
    delete: adminProcedure.input(idInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.delete(battingScorecards).where(eq(battingScorecards.id, input.id));
      return requireAffectedRows(result);
    }),
  }),
  bowlingScorecards: router({
    list: adminProcedure.input(z.object({ inningsId: idInput.shape.id.optional() }).optional()).query(async ({ input }) => {
      const db = await requireDb();
      if (input?.inningsId) return db.select().from(bowlingScorecards).where(eq(bowlingScorecards.inningsId, input.inningsId)).orderBy(desc(bowlingScorecards.wickets), bowlingScorecards.runsConceded);
      return db.select().from(bowlingScorecards).orderBy(desc(bowlingScorecards.createdAt));
    }),
    create: adminProcedure.input(bowlingInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const [created] = await db.insert(bowlingScorecards).values(input).$returningId();
      return { id: created.id };
    }),
    update: adminProcedure.input(z.object({ id: idInput.shape.id, data: bowlingInput.partial() })).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.update(bowlingScorecards).set(input.data).where(eq(bowlingScorecards.id, input.id));
      return requireAffectedRows(result, async () => Boolean((await db.select({ id: bowlingScorecards.id }).from(bowlingScorecards).where(eq(bowlingScorecards.id, input.id)).limit(1))[0]));
    }),
    delete: adminProcedure.input(idInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.delete(bowlingScorecards).where(eq(bowlingScorecards.id, input.id));
      return requireAffectedRows(result);
    }),
  }),
  partnerships: router({
    list: adminProcedure.input(z.object({ inningsId: idInput.shape.id.optional() }).optional()).query(async ({ input }) => {
      const db = await requireDb();
      if (input?.inningsId) return db.select().from(partnerships).where(eq(partnerships.inningsId, input.inningsId)).orderBy(partnerships.wicketNumber);
      return db.select().from(partnerships).orderBy(desc(partnerships.createdAt));
    }),
    create: adminProcedure.input(partnershipCreateInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const [created] = await db.insert(partnerships).values(input).$returningId();
      return { id: created.id };
    }),
    update: adminProcedure.input(z.object({ id: idInput.shape.id, data: partnershipUpdateInput })).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.update(partnerships).set(input.data).where(eq(partnerships.id, input.id));
      return requireAffectedRows(result, async () => Boolean((await db.select({ id: partnerships.id }).from(partnerships).where(eq(partnerships.id, input.id)).limit(1))[0]));
    }),
    delete: adminProcedure.input(idInput).mutation(async ({ input }) => {
      const db = await requireDb();
      const result = await db.delete(partnerships).where(eq(partnerships.id, input.id));
      return requireAffectedRows(result);
    }),
  }),
});
