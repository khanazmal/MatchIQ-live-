import type { CricketMatchCard, CricketTeamCard } from "../../shared/cricket-samples";

const LIVE_MATCHES_URL = "https://cricketliveapi.com/api/v1/cricket/matches/live";
const CACHE_TTL_MS = 30 * 60_000;
const MAX_FALLBACK_429_BACKOFF_MS = 24 * 60 * 60_000;
const PROVIDER_ID_FLOOR = -1_100_000_000;
const PROVIDER_ID_RANGE = 800_000_000;

type JsonRecord = Record<string, unknown>;

export type CricketLiveFeedStatus = "unconfigured" | "connected" | "empty" | "error";

export type CricketLiveFeedState = {
  status: CricketLiveFeedStatus;
  count: number;
  upcomingCount: number;
  message: string;
  fetchedAt: string | null;
};

export type CricketLiveFeedResult = {
  matches: CricketMatchCard[];
  feed: CricketLiveFeedState;
};

let cachedResult: CricketLiveFeedResult | null = null;
let cacheExpiresAt = 0;
let inFlightRequest: Promise<CricketLiveFeedResult> | null = null;
let nextCacheTtlMs = CACHE_TTL_MS;
let consecutive429Responses = 0;

function asRecord(value: unknown): JsonRecord | null {
  return value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as JsonRecord
    : null;
}

function textValue(value: unknown): string | null {
  if (typeof value === "string" && value.trim()) return value.trim();
  if (typeof value === "number" && Number.isFinite(value)) return String(value);
  return null;
}

function firstText(record: JsonRecord, keys: string[]): string | null {
  for (const key of keys) {
    const value = textValue(record[key]);
    if (value) return value;
  }
  return null;
}

function teamName(value: unknown): string | null {
  const direct = textValue(value);
  if (direct) return direct;
  const record = asRecord(value);
  return record ? firstText(record, ["full_name", "fullName", "name", "team_name", "teamName", "short_name", "shortName"]) : null;
}

function splitTeams(value: unknown): [string, string] | null {
  if (Array.isArray(value)) {
    const names = value.map(teamName).filter((name): name is string => Boolean(name));
    return names.length >= 2 ? [names[0], names[1]] : null;
  }
  const record = asRecord(value);
  if (record) {
    const first = teamName(record.team1 ?? record.team_a ?? record.home ?? record.home_team);
    const second = teamName(record.team2 ?? record.team_b ?? record.away ?? record.away_team);
    return first && second ? [first, second] : null;
  }
  const label = textValue(value);
  if (!label) return null;
  const names = label.split(/\s+v(?:s\.?)?\s+/i).map(name => name.trim()).filter(Boolean);
  return names.length >= 2 ? [names[0], names[1]] : null;
}

function shortName(name: string): string {
  const words = name.trim().split(/\s+/).filter(Boolean);
  const initials = words.map(word => word[0]).join("").toUpperCase();
  const compact = name.replace(/[^a-z0-9]/gi, "").toUpperCase();
  return (initials.length >= 2 ? initials : compact).slice(0, 3) || "TBD";
}

function stableNegativeId(value: string, salt: string): number {
  let hash = 2_166_136_261;
  for (const character of `${salt}:${value}`) {
    hash ^= character.charCodeAt(0);
    hash = Math.imul(hash, 16_777_619);
  }
  return PROVIDER_ID_FLOOR - ((hash >>> 0) % PROVIDER_ID_RANGE);
}

function formatValue(value: string | null): CricketMatchCard["format"] {
  const normalized = value?.toLowerCase().replace(/[^a-z0-9]/g, "") ?? "";
  if (normalized.includes("t20")) return "T20";
  if (normalized.includes("odi") || normalized.includes("oneday")) return "ODI";
  if (normalized.includes("test")) return "Test";
  if (normalized.includes("t10")) return "T10";
  return "Other";
}

function providerMatchStatus(record: JsonRecord): CricketMatchCard["status"] {
  const status = firstText(record, ["status", "short_status", "match_status"]);
  const state = firstText(record, ["state", "state_title"]);
  const value = `${status ?? ""} ${state ?? ""}`.toLowerCase();
  if (/abandon|cancel|no[ -]?result/.test(value)) return "abandoned";
  if (/preview|scheduled|upcoming|pre[ -]?match|toss|not started/.test(value)) return "upcoming";
  if (/complete|finished|match over|result|\bwon\b|\bdraw\b/.test(value)) return "completed";
  if (/\blive\b|in[\s_-]?progress|in play|playing|innings|lunch|tea|drinks|stumps|break/.test(value)) return "live";
  return "upcoming";
}

function normalizeOvers(value: string): string | null {
  const normalized = value.trim().replace(/\s*ov$/i, "");
  return /^\d+(?:\.[0-5])?$/.test(normalized) ? normalized : null;
}

function cleanDirectScore(value: string): string {
  let normalized = value.trim();
  const suffix = /\s*\(([^()]*)\)\s*$/.exec(normalized);
  if (suffix) {
    const overMatch = /^(\d+(?:\.\d+)?)\s*ov$/i.exec(suffix[1].trim());
    if (overMatch) {
      const overs = normalizeOvers(overMatch[1]);
      normalized = overs
        ? `${normalized.slice(0, suffix.index).trim()} (${overs} ov)`
        : normalized.slice(0, suffix.index).trim();
    }
  }
  return normalized.replace(/\/\s*(?=\(|$)/g, "").trim();
}

function scoreText(value: unknown): string | null {
  const direct = textValue(value);
  if (direct) return cleanDirectScore(direct);
  if (Array.isArray(value)) {
    const parts = value.map(scoreText).filter((part): part is string => Boolean(part));
    return parts.length ? [...new Set(parts)].join(" · ") : null;
  }
  const record = asRecord(value);
  if (!record) return null;
  const display = firstText(record, ["display", "text", "summary", "score_text", "scoreText", "scoreline", "scoreLine", "formatted"]);
  if (display) return cleanDirectScore(display);
  const total = firstText(record, ["total", "runs", "total_runs", "totalRuns", "score"]);
  const wickets = firstText(record, ["wickets", "outs", "wicket_count", "wicketCount"]);
  const oversValue = firstText(record, ["overs", "over", "current_overs", "currentOvers"]);
  const overs = oversValue ? normalizeOvers(oversValue) : null;
  if (total) {
    const normalizedTotal = wickets && !/\/\d+/.test(total) ? `${total}/${wickets}` : total;
    const oversLabel = overs ? ` (${overs} ov)` : "";
    return `${normalizedTotal}${oversLabel}`;
  }
  const parts = ["innings", "scores", "team_a", "teamA", "team1", "home", "team_b", "teamB", "team2", "away", "current", "score", "live_score"]
    .map(key => scoreText(record[key]))
    .filter((part): part is string => Boolean(part));
  return parts.length ? [...new Set(parts)].join(" · ") : null;
}

function scheduledTime(record: JsonRecord, fallback: Date): string {
  const value = firstText(record, ["scheduled_at", "scheduledAt", "start_time", "startTime", "date", "match_date"]);
  if (value) {
    const noYear = /^([A-Za-z]{3})\s+(\d{1,2}),\s*(\d{1,2}):(\d{2})\s+GMT$/i.exec(value);
    if (noYear) {
      const month = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"].indexOf(noYear[1].toLowerCase());
      if (month >= 0) {
        let year = fallback.getUTCFullYear();
        let timestamp = Date.UTC(year, month, Number(noYear[2]), Number(noYear[3]), Number(noYear[4]));
        const status = providerMatchStatus(record);
        if (status === "upcoming" && timestamp < fallback.getTime() - 86_400_000) {
          year += 1;
          timestamp = Date.UTC(year, month, Number(noYear[2]), Number(noYear[3]), Number(noYear[4]));
        } else if (status === "completed" && timestamp > fallback.getTime() + 86_400_000) {
          year -= 1;
          timestamp = Date.UTC(year, month, Number(noYear[2]), Number(noYear[3]), Number(noYear[4]));
        }
        return new Date(timestamp).toISOString();
      }
    }
    const parsed = new Date(value);
    if (!Number.isNaN(parsed.getTime()) && parsed.getUTCFullYear() !== 2001) return parsed.toISOString();
  }
  return fallback.toISOString();
}

function normalizeMatch(value: unknown, index: number, fetchedAt: Date): CricketMatchCard {
  const record = asRecord(value);
  if (!record) throw new Error(`Invalid CricketLiveAPI match at index ${index}.`);

  const providerMatchId = firstText(record, ["match_id", "matchId", "id"]);
  const firstTeamRecord = asRecord(record.first_team ?? record.firstTeam);
  const secondTeamRecord = asRecord(record.second_team ?? record.secondTeam);
  const names = splitTeams(record.teams)
    ?? (() => {
      const first = teamName(record.first_team ?? record.firstTeam ?? record.team_a ?? record.teamA ?? record.team1 ?? record.home_team ?? record.homeTeam);
      const second = teamName(record.second_team ?? record.secondTeam ?? record.team_b ?? record.teamB ?? record.team2 ?? record.away_team ?? record.awayTeam);
      return first && second ? [first, second] as [string, string] : null;
    })();
  if (!providerMatchId || !names) {
    throw new Error(`CricketLiveAPI match ${index} is missing its match ID or two team names.`);
  }

  const [teamAName, teamBName] = names;
  const firstCode = firstText(firstTeamRecord ?? {}, ["short_name", "shortName", "code", "name"]);
  const secondCode = firstText(secondTeamRecord ?? {}, ["short_name", "shortName", "code", "name"]);
  const teamA: CricketTeamCard = {
    id: stableNegativeId(providerMatchId, "team-a"),
    name: teamAName,
    shortName: firstCode && firstCode.length <= 6 ? firstCode : shortName(teamAName),
    country: null,
  };
  const teamB: CricketTeamCard = {
    id: stableNegativeId(providerMatchId, "team-b"),
    name: teamBName,
    shortName: secondCode && secondCode.length <= 6 ? secondCode : shortName(teamBName),
    country: null,
  };
  const scoreValue = record.score ?? record.current_score ?? record.live_score ?? record.score_text;
  const directScore = scoreText(scoreValue);
  const teamAScore = scoreText(firstTeamRecord?.innings) ?? scoreText(firstTeamRecord?.score);
  const teamBScore = scoreText(secondTeamRecord?.innings) ?? scoreText(secondTeamRecord?.score);
  const teamScoreParts = [
    [teamAName, teamAScore],
    [teamBName, teamBScore],
  ].filter((entry): entry is [string, string] => Boolean(entry[1]));
  const liveScore = directScore ?? (teamScoreParts.length ? teamScoreParts.map(([name, score]) => `${name} ${score}`).join(" · ") : null);
  const title = firstText(record, ["title", "match_title", "match_desc", "name"]) ?? `${teamAName} v ${teamBName}`;

  return {
    id: stableNegativeId(providerMatchId, "match"),
    providerMatchId,
    title,
    format: formatValue(firstText(record, ["format", "match_format", "type"])),
    competition: firstText(record, ["competition", "series", "series_name", "tournament"]),
    venue: firstText(record, ["venue", "ground", "stadium"]),
    scheduledAt: scheduledTime(record, fetchedAt),
    status: providerMatchStatus(record),
    teamA,
    teamB,
    currentInnings: null,
    result: null,
    summary: firstText(record, ["status_detail", "short_status", "summary"]),
    liveScore,
    teamAScore,
    teamBScore,
    dataSource: "cricketliveapi",
    innings: [],
  };
}

/** Normalize the observed provider envelope and the provider's published example envelope. */
export function normalizeCricketLiveResponse(payload: unknown, fetchedAt = new Date()): CricketMatchCard[] {
  const root = asRecord(payload);
  if (!root || !(root.success === true || root.status === "success")) {
    throw new Error("CricketLiveAPI did not return a successful response envelope.");
  }

  const dataRecord = asRecord(root.data);
  const rows = Array.isArray(root.data)
    ? root.data
    : dataRecord && Array.isArray(dataRecord.matches)
      ? dataRecord.matches
      : null;
  if (!rows) throw new Error("CricketLiveAPI returned an unsupported live-match response shape.");
  return rows.map((row, index) => normalizeMatch(row, index, fetchedAt));
}

function makeResult(
  status: CricketLiveFeedStatus,
  matches: CricketMatchCard[],
  message: string,
  fetchedAt: string | null,
): CricketLiveFeedResult {
  const count = matches.filter(match => match.status === "live").length;
  const upcomingCount = matches.filter(match => match.status === "upcoming").length;
  return {
    matches,
    feed: { status, count, upcomingCount, message, fetchedAt },
  };
}

export function parseRetryAfterMs(value: string | null, now = Date.now()): number | null {
  const header = value?.trim();
  if (!header) return null;

  if (/^\d+$/.test(header)) {
    const seconds = Number(header);
    const maxSafeDelay = Number.MAX_SAFE_INTEGER - now;
    const delay = seconds * 1000;
    return Number.isFinite(delay) ? Math.min(delay, maxSafeDelay) : maxSafeDelay;
  }

  const retryAt = Date.parse(header);
  if (!Number.isFinite(retryAt) || retryAt <= now) return null;
  return Math.min(retryAt - now, Number.MAX_SAFE_INTEGER - now);
}

export function computeRateLimitBackoffMs(retryAfterMs: number | null, consecutive429s: number): number {
  const exponent = Math.min(Math.max(Math.floor(consecutive429s) - 1, 0), 31);
  const fallbackMs = Math.min(CACHE_TTL_MS * 2 ** exponent, MAX_FALLBACK_429_BACKOFF_MS);
  const requestedMs = retryAfterMs !== null && Number.isFinite(retryAfterMs) ? Math.max(0, retryAfterMs) : 0;
  return Math.max(fallbackMs, requestedMs);
}

async function requestLiveMatches(token: string): Promise<CricketLiveFeedResult> {
  const fetchedAt = new Date();
  try {
    const response = await fetch(LIVE_MATCHES_URL, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: "application/json",
      },
      signal: AbortSignal.timeout(10_000),
    });
    if (response.status === 429) {
      consecutive429Responses += 1;
      const retryAfterMs = parseRetryAfterMs(response.headers.get("Retry-After"), fetchedAt.getTime());
      nextCacheTtlMs = computeRateLimitBackoffMs(retryAfterMs, consecutive429Responses);
    } else {
      consecutive429Responses = 0;
      nextCacheTtlMs = CACHE_TTL_MS;
    }
    if (!response.ok) {
      return makeResult("error", [], `CricketLiveAPI returned HTTP ${response.status}.`, fetchedAt.toISOString());
    }

    const payload: unknown = await response.json();
    const matches = normalizeCricketLiveResponse(payload, fetchedAt);
    const liveCount = matches.filter(match => match.status === "live").length;
    const upcomingCount = matches.filter(match => match.status === "upcoming").length;
    if (liveCount === 0) {
      const upcomingMessage = upcomingCount ? ` The feed includes ${upcomingCount} upcoming/preview fixture${upcomingCount === 1 ? "" : "s"}.` : "";
      return makeResult("empty", matches, `CricketLiveAPI is connected, but no matches are in play.${upcomingMessage}`, fetchedAt.toISOString());
    }
    const upcomingMessage = upcomingCount ? ` It also includes ${upcomingCount} upcoming/preview fixture${upcomingCount === 1 ? "" : "s"}.` : "";
    return makeResult("connected", matches, `CricketLiveAPI returned ${liveCount} in-progress match${liveCount === 1 ? "" : "es"}.${upcomingMessage}`, fetchedAt.toISOString());
  } catch {
    return makeResult(
      "error",
      [],
      "CricketLiveAPI could not be reached or returned an invalid response. Saved and sample fixtures remain available.",
      fetchedAt.toISOString(),
    );
  }
}

export async function getCricketLiveFeed(): Promise<CricketLiveFeedResult> {
  const token = process.env.CRICKETLIVEAPI_TOKEN?.trim();
  if (!token) {
    return makeResult(
      "unconfigured",
      [],
      "CRICKETLIVEAPI_TOKEN is not configured for this backend environment.",
      null,
    );
  }

  const now = Date.now();
  if (cachedResult && now < cacheExpiresAt) return cachedResult;
  if (inFlightRequest) return inFlightRequest;

  inFlightRequest = requestLiveMatches(token).then(result => {
    cachedResult = result;
    cacheExpiresAt = Date.now() + nextCacheTtlMs;
    return result;
  }).finally(() => {
    inFlightRequest = null;
  });
  return inFlightRequest;
}
