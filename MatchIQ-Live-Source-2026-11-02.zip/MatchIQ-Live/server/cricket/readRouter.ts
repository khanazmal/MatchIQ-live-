import { TRPCError } from "@trpc/server";
import { desc, eq, inArray, sql } from "drizzle-orm";
import { alias } from "drizzle-orm/mysql-core";
import { z } from "zod";
import {
  battingScorecards,
  bowlingScorecards,
  innings,
  matches,
  partnerships,
  players,
  teams,
} from "../../drizzle/schema";
import { sampleAnalytics, sampleMatches, samplePlayerStatistics, type CricketInningsCard, type CricketMatchCard, type PlayerStatistic } from "../../shared/cricket-samples";
import { publicProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { battingAverage, bowlingEconomy, battingStrikeRate, roundToTwo } from "./logic";
import { getCricketLiveFeed } from "./provider";

const statuses = ["upcoming", "live", "completed", "abandoned"] as const;
const teamA = alias(teams, "team_a");
const teamB = alias(teams, "team_b");
const batterOnePlayer = alias(players, "partnership_batter_one");
const batterTwoPlayer = alias(players, "partnership_batter_two");

async function getPlayerStatistics(db: NonNullable<Awaited<ReturnType<typeof getDb>>>): Promise<PlayerStatistic[]> {
  const battingRows = await db
    .select({
      id: players.id,
      playerName: players.fullName,
      teamName: teams.shortName,
      role: players.role,
      runs: sql<number>`COALESCE(SUM(${battingScorecards.runs}), 0)`.mapWith(Number),
      ballsFaced: sql<number>`COALESCE(SUM(${battingScorecards.ballsFaced}), 0)`.mapWith(Number),
      dismissals: sql<number>`COALESCE(SUM(CASE WHEN ${battingScorecards.isNotOut} = 0 THEN 1 ELSE 0 END), 0)`.mapWith(Number),
    })
    .from(players)
    .leftJoin(teams, eq(players.teamId, teams.id))
    .leftJoin(battingScorecards, eq(players.id, battingScorecards.playerId))
    .groupBy(players.id, players.fullName, players.role, teams.shortName);

  const bowlingRows = await db
    .select({
      id: bowlingScorecards.playerId,
      wickets: sql<number>`COALESCE(SUM(${bowlingScorecards.wickets}), 0)`.mapWith(Number),
      runsConceded: sql<number>`COALESCE(SUM(${bowlingScorecards.runsConceded}), 0)`.mapWith(Number),
      legalBalls: sql<number>`COALESCE(SUM(${bowlingScorecards.legalBalls}), 0)`.mapWith(Number),
    })
    .from(bowlingScorecards)
    .groupBy(bowlingScorecards.playerId);

  const bowlingByPlayer = new Map(bowlingRows.map(row => [row.id, row]));
  return battingRows
    .map(row => {
      const bowling = bowlingByPlayer.get(row.id);
      return {
        id: row.id,
        playerName: row.playerName,
        teamName: row.teamName ?? "—",
        role: row.role,
        runs: row.runs,
        wickets: bowling?.wickets ?? 0,
        battingAverage: roundToTwo(battingAverage(row.runs, row.dismissals)),
        strikeRate: roundToTwo(battingStrikeRate(row.runs, row.ballsFaced)),
        bowlingEconomy: roundToTwo(bowlingEconomy(bowling?.runsConceded ?? 0, bowling?.legalBalls ?? 0)),
      };
    })
    .sort((a, b) => b.runs - a.runs);
}

async function getDatabaseMatches() {
  const db = await getDb();
  if (!db) return null;

  const query = db
    .select({
      id: matches.id,
      title: matches.title,
      format: matches.format,
      competition: matches.competition,
      venue: matches.venue,
      scheduledAt: matches.scheduledAt,
      status: matches.status,
      teamA: { id: teamA.id, name: teamA.name, shortName: teamA.shortName, country: teamA.country },
      teamB: { id: teamB.id, name: teamB.name, shortName: teamB.shortName, country: teamB.country },
      currentInnings: matches.currentInnings,
      result: matches.result,
      summary: matches.summary,
      dataSource: matches.dataSource,
    })
    .from(matches)
    .innerJoin(teamA, eq(matches.teamAId, teamA.id))
    .innerJoin(teamB, eq(matches.teamBId, teamB.id));

  const rows = await query
    .orderBy(desc(matches.scheduledAt))
    .limit(100);
  if (!rows.length) return [];

  const matchIds = rows.map(row => row.id);
  const inningsRows = await db
    .select()
    .from(innings)
    .where(inArray(innings.matchId, matchIds))
    .orderBy(innings.matchId, innings.inningsNumber);
  const byMatch = new Map<number, CricketInningsCard[]>();
  for (const inning of inningsRows) {
    const list = byMatch.get(inning.matchId) ?? [];
    list.push({
      id: inning.id,
      inningsNumber: inning.inningsNumber,
      battingTeamId: inning.battingTeamId,
      bowlingTeamId: inning.bowlingTeamId,
      totalRuns: inning.totalRuns,
      wickets: inning.wickets,
      legalBalls: inning.legalBalls,
      extras: inning.extras,
      target: inning.target,
      status: inning.status,
      declared: inning.declared,
      batting: [],
      bowling: [],
      partnerships: [],
    });
    byMatch.set(inning.matchId, list);
  }

  return rows.map(row => ({
    ...row,
    scheduledAt: row.scheduledAt.toISOString(),
    dataSource: row.dataSource,
    innings: byMatch.get(row.id) ?? [],
  })) satisfies CricketMatchCard[];
}

async function getDatabaseMatchDetails(matchId: number): Promise<CricketMatchCard | null> {
  const db = await getDb();
  if (!db) return null;

  const [match] = await db
    .select({
      id: matches.id,
      title: matches.title,
      format: matches.format,
      competition: matches.competition,
      venue: matches.venue,
      scheduledAt: matches.scheduledAt,
      status: matches.status,
      teamA: { id: teamA.id, name: teamA.name, shortName: teamA.shortName, country: teamA.country },
      teamB: { id: teamB.id, name: teamB.name, shortName: teamB.shortName, country: teamB.country },
      currentInnings: matches.currentInnings,
      result: matches.result,
      summary: matches.summary,
      dataSource: matches.dataSource,
    })
    .from(matches)
    .innerJoin(teamA, eq(matches.teamAId, teamA.id))
    .innerJoin(teamB, eq(matches.teamBId, teamB.id))
    .where(eq(matches.id, matchId))
    .limit(1);
  if (!match) return null;

  const inningsRows = await db.select().from(innings).where(eq(innings.matchId, matchId)).orderBy(innings.inningsNumber);
  const inningIds = inningsRows.map(inning => inning.id);
  if (!inningIds.length) {
    return { ...match, scheduledAt: match.scheduledAt.toISOString(), innings: [] };
  }

  const [battingRows, bowlingRows, partnershipRows] = await Promise.all([
    db.select({
      id: battingScorecards.id,
      inningsId: battingScorecards.inningsId,
      playerId: players.id,
      playerName: players.fullName,
      battingPosition: battingScorecards.battingPosition,
      runs: battingScorecards.runs,
      ballsFaced: battingScorecards.ballsFaced,
      fours: battingScorecards.fours,
      sixes: battingScorecards.sixes,
      dismissal: battingScorecards.dismissal,
      isNotOut: battingScorecards.isNotOut,
    }).from(battingScorecards).innerJoin(players, eq(battingScorecards.playerId, players.id)).where(inArray(battingScorecards.inningsId, inningIds)).orderBy(battingScorecards.battingPosition),
    db.select({
      id: bowlingScorecards.id,
      inningsId: bowlingScorecards.inningsId,
      playerId: players.id,
      playerName: players.fullName,
      legalBalls: bowlingScorecards.legalBalls,
      maidens: bowlingScorecards.maidens,
      runsConceded: bowlingScorecards.runsConceded,
      wickets: bowlingScorecards.wickets,
      wides: bowlingScorecards.wides,
      noBalls: bowlingScorecards.noBalls,
    }).from(bowlingScorecards).innerJoin(players, eq(bowlingScorecards.playerId, players.id)).where(inArray(bowlingScorecards.inningsId, inningIds)).orderBy(bowlingScorecards.playerId),
    db.select({
      id: partnerships.id,
      inningsId: partnerships.inningsId,
      wicketNumber: partnerships.wicketNumber,
      batterOne: batterOnePlayer.fullName,
      batterTwo: batterTwoPlayer.fullName,
      runs: partnerships.runs,
      balls: partnerships.balls,
    }).from(partnerships)
      .innerJoin(batterOnePlayer, eq(partnerships.batterOneId, batterOnePlayer.id))
      .innerJoin(batterTwoPlayer, eq(partnerships.batterTwoId, batterTwoPlayer.id))
      .where(inArray(partnerships.inningsId, inningIds)).orderBy(partnerships.wicketNumber),
  ]);

  const detailInnings = inningsRows.map(inning => ({
    id: inning.id,
    inningsNumber: inning.inningsNumber,
    battingTeamId: inning.battingTeamId,
    bowlingTeamId: inning.bowlingTeamId,
    totalRuns: inning.totalRuns,
    wickets: inning.wickets,
    legalBalls: inning.legalBalls,
    extras: inning.extras,
    target: inning.target,
    status: inning.status,
    declared: inning.declared,
    batting: battingRows.filter(row => row.inningsId === inning.id).map(({ inningsId: _inningsId, ...row }) => row),
    bowling: bowlingRows.filter(row => row.inningsId === inning.id).map(({ inningsId: _inningsId, ...row }) => row),
    partnerships: partnershipRows.filter(row => row.inningsId === inning.id).map(({ id: _id, inningsId: _inningsId, ...row }) => row),
  }));

  return { ...match, scheduledAt: match.scheduledAt.toISOString(), innings: detailInnings };
}

export const cricketReadRouter = router({
  matches: router({
    list: publicProcedure.input(z.object({ status: z.enum(statuses).optional() }).optional()).query(async ({ input }) => {
      let baseItems: CricketMatchCard[] = sampleMatches;
      let source: "database" | "sample" = "sample";
      let notice: string | null = "Sample data only — no saved cricket records are available yet.";
      try {
        const items = await getDatabaseMatches();
        if (items?.length) {
          baseItems = items;
          source = "database";
          notice = null;
        }
      } catch (error) {
        console.warn("[Cricket] Could not read stored matches; serving labelled sample data.", error);
        notice = "Cricket tables could not be read yet. Saved records are unavailable; other fixtures are labelled sample data.";
      }
      const liveFeed = await getCricketLiveFeed();
      const providerIsAuthoritative = liveFeed.feed.status === "connected" || liveFeed.feed.status === "empty";
      const retainedBaseItems = providerIsAuthoritative
        ? baseItems.filter(match => !(match.dataSource === "sample" && match.status === "live"))
        : baseItems;
      const combined = [...liveFeed.matches, ...retainedBaseItems];
      const items = input?.status ? combined.filter(match => match.status === input.status) : combined;
      return { items, source, notice, liveFeed: liveFeed.feed };
    }),
    detail: publicProcedure.input(z.object({ id: z.number().int() })).query(async ({ input }) => {
      if (input.id <= -1_000_000_000) {
        const liveFeed = await getCricketLiveFeed();
        const providerMatch = liveFeed.matches.find(match => match.id === input.id);
        if (providerMatch) return providerMatch;
      }
      if (input.id < 0) {
        const sample = sampleMatches.find(match => match.id === input.id);
        if (sample) return sample;
      }
      try {
        const detail = await getDatabaseMatchDetails(input.id);
        if (detail) return detail;
      } catch (error) {
        console.error("[Cricket] Match detail query failed:", error);
        throw new TRPCError({ code: "SERVICE_UNAVAILABLE", message: "Could not load this match. Check the database migration and try again." });
      }
      throw new TRPCError({ code: "NOT_FOUND", message: "Match not found." });
    }),
  }),
  players: router({
    statistics: publicProcedure.query(async () => {
      try {
        const db = await getDb();
        if (db) {
          const rows = await getPlayerStatistics(db);
          if (rows.length) return { items: rows, source: "database" as const, notice: null };
        }
      } catch (error) {
        console.warn("[Cricket] Could not calculate player statistics; serving labelled samples.", error);
        return { items: samplePlayerStatistics, source: "sample" as const, notice: "Player statistics are sample figures until the migration is applied and scorecards are added." };
      }
      return { items: samplePlayerStatistics, source: "sample" as const, notice: "Player statistics are sample figures until the migration is applied and scorecards are added." };
    }),
  }),
  analytics: router({
    overview: publicProcedure.query(async () => {
      try {
        const db = await getDb();
        if (db) {
          const [[totals], [scoreTotals], teamRuns, playerStats] = await Promise.all([
            db.select({
              matchCount: sql<number>`COUNT(*)`.mapWith(Number),
              liveMatches: sql<number>`COALESCE(SUM(CASE WHEN ${matches.status} = 'live' THEN 1 ELSE 0 END), 0)`.mapWith(Number),
            }).from(matches),
            db.select({
              totalRuns: sql<number>`COALESCE(SUM(${innings.totalRuns}), 0)`.mapWith(Number),
              totalWickets: sql<number>`COALESCE(SUM(${innings.wickets}), 0)`.mapWith(Number),
            }).from(innings),
            db.select({
              name: teams.shortName,
              runs: sql<number>`COALESCE(SUM(${innings.totalRuns}), 0)`.mapWith(Number),
            }).from(innings).innerJoin(teams, eq(innings.battingTeamId, teams.id)).groupBy(teams.id, teams.shortName).orderBy(desc(sql`SUM(${innings.totalRuns})`)).limit(6),
            getPlayerStatistics(db),
          ]);
          if ((totals?.matchCount ?? 0) > 0 || playerStats.length > 0) {
            return {
              source: "database" as const,
              notice: null,
              totalRuns: scoreTotals?.totalRuns ?? 0,
              totalWickets: scoreTotals?.totalWickets ?? 0,
              liveMatches: totals?.liveMatches ?? 0,
              topBatters: playerStats.slice().sort((a, b) => b.runs - a.runs).slice(0, 5),
              topBowlers: playerStats.slice().sort((a, b) => b.wickets - a.wickets).slice(0, 5),
              teamRuns,
            };
          }
        }
      } catch (error) {
        console.warn("[Cricket] SQL analytics unavailable; using labelled sample statistics.", error);
      }
      return { ...sampleAnalytics, teamRuns: [{ name: "HBS", runs: 334 }, { name: "HTH", runs: 186 }, { name: "CLC", runs: 264 }, { name: "CAC", runs: 246 }] };
    }),
  }),
});
