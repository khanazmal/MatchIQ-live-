import { describe, expect, it } from "vitest";
import { battingAverage, battingStrikeRate, bowlingEconomy, formatOvers, roundToTwo } from "./logic";

describe("cricket score calculations", () => {
  it("formats legal balls as cricket overs, not decimal overs", () => {
    expect(formatOvers(0)).toBe("0.0");
    expect(formatOvers(17 * 6 + 2)).toBe("17.2");
    expect(formatOvers(120)).toBe("20.0");
  });

  it("calculates batting average, strike rate and bowling economy safely", () => {
    expect(roundToTwo(battingAverage(200, 5))).toBe(40);
    expect(roundToTwo(battingStrikeRate(48, 32))).toBe(150);
    expect(roundToTwo(bowlingEconomy(35, 24))).toBe(8.75);
    expect(battingStrikeRate(0, 0)).toBe(0);
    expect(bowlingEconomy(0, 0)).toBe(0);
  });

  it("keeps an unbeaten player average equal to runs scored", () => {
    expect(battingAverage(35, 0)).toBe(35);
  });
});
