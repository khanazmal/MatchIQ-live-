import {
  boolean,
  datetime,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

/** Existing application users. Keep the auth/session identity and role unchanged. */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const teams = mysqlTable(
  "teams",
  {
    id: int("id").autoincrement().primaryKey(),
    name: varchar("name", { length: 120 }).notNull(),
    shortName: varchar("shortName", { length: 12 }).notNull().unique(),
    country: varchar("country", { length: 80 }).notNull(),
    logoUrl: varchar("logoUrl", { length: 500 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("teams_name_idx").on(table.name)],
);

export const players = mysqlTable(
  "players",
  {
    id: int("id").autoincrement().primaryKey(),
    teamId: int("teamId").references(() => teams.id, { onDelete: "set null" }),
    fullName: varchar("fullName", { length: 160 }).notNull(),
    role: mysqlEnum("role", ["batter", "bowler", "all_rounder", "wicket_keeper"])
      .default("all_rounder")
      .notNull(),
    battingStyle: varchar("battingStyle", { length: 50 }),
    bowlingStyle: varchar("bowlingStyle", { length: 80 }),
    country: varchar("country", { length: 80 }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [index("players_team_idx").on(table.teamId), index("players_name_idx").on(table.fullName)],
);

export const matches = mysqlTable(
  "matches",
  {
    id: int("id").autoincrement().primaryKey(),
    providerMatchId: varchar("providerMatchId", { length: 100 }).unique(),
    title: varchar("title", { length: 180 }).notNull(),
    format: mysqlEnum("format", ["T20", "ODI", "Test", "T10", "Other"]).notNull(),
    competition: varchar("competition", { length: 160 }),
    venue: varchar("venue", { length: 180 }),
    scheduledAt: datetime("scheduledAt", { mode: "date" }).notNull(),
    status: mysqlEnum("status", ["upcoming", "live", "completed", "abandoned"])
      .default("upcoming")
      .notNull(),
    teamAId: int("teamAId").notNull().references(() => teams.id),
    teamBId: int("teamBId").notNull().references(() => teams.id),
    currentInnings: int("currentInnings"),
    tossWinnerTeamId: int("tossWinnerTeamId").references(() => teams.id, { onDelete: "set null" }),
    tossDecision: mysqlEnum("tossDecision", ["bat", "bowl"]),
    winnerTeamId: int("winnerTeamId").references(() => teams.id, { onDelete: "set null" }),
    result: text("result"),
    summary: text("summary"),
    dataSource: mysqlEnum("dataSource", ["sample", "manual", "cricbuzz", "other"])
      .default("manual")
      .notNull(),
    lastSyncedAt: datetime("lastSyncedAt", { mode: "date" }),
    createdBy: int("createdBy").references(() => users.id, { onDelete: "set null" }),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    index("matches_status_time_idx").on(table.status, table.scheduledAt),
    index("matches_team_a_idx").on(table.teamAId),
    index("matches_team_b_idx").on(table.teamBId),
  ],
);

export const innings = mysqlTable(
  "innings",
  {
    id: int("id").autoincrement().primaryKey(),
    matchId: int("matchId").notNull().references(() => matches.id, { onDelete: "cascade" }),
    inningsNumber: int("inningsNumber").notNull(),
    battingTeamId: int("battingTeamId").notNull().references(() => teams.id),
    bowlingTeamId: int("bowlingTeamId").notNull().references(() => teams.id),
    totalRuns: int("totalRuns").default(0).notNull(),
    wickets: int("wickets").default(0).notNull(),
    legalBalls: int("legalBalls").default(0).notNull(),
    extras: int("extras").default(0).notNull(),
    target: int("target"),
    status: mysqlEnum("status", ["upcoming", "in_progress", "completed"]).default("upcoming").notNull(),
    declared: boolean("declared").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("innings_match_number_uq").on(table.matchId, table.inningsNumber),
    index("innings_batting_team_idx").on(table.battingTeamId),
  ],
);

export const battingScorecards = mysqlTable(
  "batting_scorecards",
  {
    id: int("id").autoincrement().primaryKey(),
    inningsId: int("inningsId").notNull().references(() => innings.id, { onDelete: "cascade" }),
    playerId: int("playerId").notNull().references(() => players.id),
    battingPosition: int("battingPosition").notNull(),
    runs: int("runs").default(0).notNull(),
    ballsFaced: int("ballsFaced").default(0).notNull(),
    fours: int("fours").default(0).notNull(),
    sixes: int("sixes").default(0).notNull(),
    dismissal: varchar("dismissal", { length: 220 }),
    isNotOut: boolean("isNotOut").default(false).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("batting_innings_player_uq").on(table.inningsId, table.playerId),
    index("batting_player_idx").on(table.playerId),
  ],
);

export const bowlingScorecards = mysqlTable(
  "bowling_scorecards",
  {
    id: int("id").autoincrement().primaryKey(),
    inningsId: int("inningsId").notNull().references(() => innings.id, { onDelete: "cascade" }),
    playerId: int("playerId").notNull().references(() => players.id),
    legalBalls: int("legalBalls").default(0).notNull(),
    maidens: int("maidens").default(0).notNull(),
    runsConceded: int("runsConceded").default(0).notNull(),
    wickets: int("wickets").default(0).notNull(),
    wides: int("wides").default(0).notNull(),
    noBalls: int("noBalls").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("bowling_innings_player_uq").on(table.inningsId, table.playerId),
    index("bowling_player_idx").on(table.playerId),
  ],
);

export const partnerships = mysqlTable(
  "partnerships",
  {
    id: int("id").autoincrement().primaryKey(),
    inningsId: int("inningsId").notNull().references(() => innings.id, { onDelete: "cascade" }),
    wicketNumber: int("wicketNumber").notNull(),
    batterOneId: int("batterOneId").notNull().references(() => players.id),
    batterTwoId: int("batterTwoId").notNull().references(() => players.id),
    runs: int("runs").default(0).notNull(),
    balls: int("balls").default(0).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
    updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  },
  table => [
    uniqueIndex("partnerships_innings_wicket_uq").on(table.inningsId, table.wicketNumber),
    index("partnerships_batters_idx").on(table.batterOneId, table.batterTwoId),
  ],
);

export type Team = typeof teams.$inferSelect;
export type NewTeam = typeof teams.$inferInsert;
export type Player = typeof players.$inferSelect;
export type NewPlayer = typeof players.$inferInsert;
export type Match = typeof matches.$inferSelect;
export type NewMatch = typeof matches.$inferInsert;
export type Innings = typeof innings.$inferSelect;
export type NewInnings = typeof innings.$inferInsert;
export type BattingScorecard = typeof battingScorecards.$inferSelect;
export type NewBattingScorecard = typeof battingScorecards.$inferInsert;
export type BowlingScorecard = typeof bowlingScorecards.$inferSelect;
export type NewBowlingScorecard = typeof bowlingScorecards.$inferInsert;
export type Partnership = typeof partnerships.$inferSelect;
export type NewPartnership = typeof partnerships.$inferInsert;
