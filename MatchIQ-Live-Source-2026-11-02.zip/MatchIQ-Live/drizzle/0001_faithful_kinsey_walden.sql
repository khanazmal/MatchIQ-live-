CREATE TABLE `batting_scorecards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inningsId` int NOT NULL,
	`playerId` int NOT NULL,
	`battingPosition` int NOT NULL,
	`runs` int NOT NULL DEFAULT 0,
	`ballsFaced` int NOT NULL DEFAULT 0,
	`fours` int NOT NULL DEFAULT 0,
	`sixes` int NOT NULL DEFAULT 0,
	`dismissal` varchar(220),
	`isNotOut` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `batting_scorecards_id` PRIMARY KEY(`id`),
	CONSTRAINT `batting_innings_player_uq` UNIQUE(`inningsId`,`playerId`)
);
--> statement-breakpoint
CREATE TABLE `bowling_scorecards` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inningsId` int NOT NULL,
	`playerId` int NOT NULL,
	`legalBalls` int NOT NULL DEFAULT 0,
	`maidens` int NOT NULL DEFAULT 0,
	`runsConceded` int NOT NULL DEFAULT 0,
	`wickets` int NOT NULL DEFAULT 0,
	`wides` int NOT NULL DEFAULT 0,
	`noBalls` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bowling_scorecards_id` PRIMARY KEY(`id`),
	CONSTRAINT `bowling_innings_player_uq` UNIQUE(`inningsId`,`playerId`)
);
--> statement-breakpoint
CREATE TABLE `innings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`matchId` int NOT NULL,
	`inningsNumber` int NOT NULL,
	`battingTeamId` int NOT NULL,
	`bowlingTeamId` int NOT NULL,
	`totalRuns` int NOT NULL DEFAULT 0,
	`wickets` int NOT NULL DEFAULT 0,
	`legalBalls` int NOT NULL DEFAULT 0,
	`extras` int NOT NULL DEFAULT 0,
	`target` int,
	`status` enum('upcoming','in_progress','completed') NOT NULL DEFAULT 'upcoming',
	`declared` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `innings_id` PRIMARY KEY(`id`),
	CONSTRAINT `innings_match_number_uq` UNIQUE(`matchId`,`inningsNumber`)
);
--> statement-breakpoint
CREATE TABLE `matches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`providerMatchId` varchar(100),
	`title` varchar(180) NOT NULL,
	`format` enum('T20','ODI','Test','T10','Other') NOT NULL,
	`competition` varchar(160),
	`venue` varchar(180),
	`scheduledAt` datetime NOT NULL,
	`status` enum('upcoming','live','completed','abandoned') NOT NULL DEFAULT 'upcoming',
	`teamAId` int NOT NULL,
	`teamBId` int NOT NULL,
	`currentInnings` int,
	`tossWinnerTeamId` int,
	`tossDecision` enum('bat','bowl'),
	`winnerTeamId` int,
	`result` text,
	`summary` text,
	`dataSource` enum('sample','manual','cricbuzz','other') NOT NULL DEFAULT 'manual',
	`lastSyncedAt` datetime,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `matches_id` PRIMARY KEY(`id`),
	CONSTRAINT `matches_providerMatchId_unique` UNIQUE(`providerMatchId`)
);
--> statement-breakpoint
CREATE TABLE `partnerships` (
	`id` int AUTO_INCREMENT NOT NULL,
	`inningsId` int NOT NULL,
	`wicketNumber` int NOT NULL,
	`batterOneId` int NOT NULL,
	`batterTwoId` int NOT NULL,
	`runs` int NOT NULL DEFAULT 0,
	`balls` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `partnerships_id` PRIMARY KEY(`id`),
	CONSTRAINT `partnerships_innings_wicket_uq` UNIQUE(`inningsId`,`wicketNumber`)
);
--> statement-breakpoint
CREATE TABLE `players` (
	`id` int AUTO_INCREMENT NOT NULL,
	`teamId` int,
	`fullName` varchar(160) NOT NULL,
	`role` enum('batter','bowler','all_rounder','wicket_keeper') NOT NULL DEFAULT 'all_rounder',
	`battingStyle` varchar(50),
	`bowlingStyle` varchar(80),
	`country` varchar(80),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `players_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `teams` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(120) NOT NULL,
	`shortName` varchar(12) NOT NULL,
	`country` varchar(80) NOT NULL,
	`logoUrl` varchar(500),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `teams_id` PRIMARY KEY(`id`),
	CONSTRAINT `teams_shortName_unique` UNIQUE(`shortName`)
);
--> statement-breakpoint
ALTER TABLE `batting_scorecards` ADD CONSTRAINT `batting_scorecards_inningsId_innings_id_fk` FOREIGN KEY (`inningsId`) REFERENCES `innings`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `batting_scorecards` ADD CONSTRAINT `batting_scorecards_playerId_players_id_fk` FOREIGN KEY (`playerId`) REFERENCES `players`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `bowling_scorecards` ADD CONSTRAINT `bowling_scorecards_inningsId_innings_id_fk` FOREIGN KEY (`inningsId`) REFERENCES `innings`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `bowling_scorecards` ADD CONSTRAINT `bowling_scorecards_playerId_players_id_fk` FOREIGN KEY (`playerId`) REFERENCES `players`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `innings` ADD CONSTRAINT `innings_matchId_matches_id_fk` FOREIGN KEY (`matchId`) REFERENCES `matches`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `innings` ADD CONSTRAINT `innings_battingTeamId_teams_id_fk` FOREIGN KEY (`battingTeamId`) REFERENCES `teams`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `innings` ADD CONSTRAINT `innings_bowlingTeamId_teams_id_fk` FOREIGN KEY (`bowlingTeamId`) REFERENCES `teams`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `matches` ADD CONSTRAINT `matches_teamAId_teams_id_fk` FOREIGN KEY (`teamAId`) REFERENCES `teams`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `matches` ADD CONSTRAINT `matches_teamBId_teams_id_fk` FOREIGN KEY (`teamBId`) REFERENCES `teams`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `matches` ADD CONSTRAINT `matches_tossWinnerTeamId_teams_id_fk` FOREIGN KEY (`tossWinnerTeamId`) REFERENCES `teams`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `matches` ADD CONSTRAINT `matches_winnerTeamId_teams_id_fk` FOREIGN KEY (`winnerTeamId`) REFERENCES `teams`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `matches` ADD CONSTRAINT `matches_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `partnerships` ADD CONSTRAINT `partnerships_inningsId_innings_id_fk` FOREIGN KEY (`inningsId`) REFERENCES `innings`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `partnerships` ADD CONSTRAINT `partnerships_batterOneId_players_id_fk` FOREIGN KEY (`batterOneId`) REFERENCES `players`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `partnerships` ADD CONSTRAINT `partnerships_batterTwoId_players_id_fk` FOREIGN KEY (`batterTwoId`) REFERENCES `players`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `players` ADD CONSTRAINT `players_teamId_teams_id_fk` FOREIGN KEY (`teamId`) REFERENCES `teams`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `batting_player_idx` ON `batting_scorecards` (`playerId`);--> statement-breakpoint
CREATE INDEX `bowling_player_idx` ON `bowling_scorecards` (`playerId`);--> statement-breakpoint
CREATE INDEX `innings_batting_team_idx` ON `innings` (`battingTeamId`);--> statement-breakpoint
CREATE INDEX `matches_status_time_idx` ON `matches` (`status`,`scheduledAt`);--> statement-breakpoint
CREATE INDEX `matches_team_a_idx` ON `matches` (`teamAId`);--> statement-breakpoint
CREATE INDEX `matches_team_b_idx` ON `matches` (`teamBId`);--> statement-breakpoint
CREATE INDEX `partnerships_batters_idx` ON `partnerships` (`batterOneId`,`batterTwoId`);--> statement-breakpoint
CREATE INDEX `players_team_idx` ON `players` (`teamId`);--> statement-breakpoint
CREATE INDEX `players_name_idx` ON `players` (`fullName`);--> statement-breakpoint
CREATE INDEX `teams_name_idx` ON `teams` (`name`);