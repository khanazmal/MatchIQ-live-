# MatchIQ Cricket Analytics — Implementation Plan

## Product scope

Build and extend the user's Cricbuzz-style cricket analytics dashboard in the existing React/TypeScript + Vite, Node.js + Express/tRPC, MySQL + Drizzle ORM, and Recharts project. Preserve the supplied user/authentication model, existing application routes, dashboard design, player statistics, analytics, and administrator data-management features. Add a backend-only CricketLiveAPI adapter for `GET https://cricketliveapi.com/api/v1/cricket/matches/live`, authenticated by the protected project environment variable `CRICKETLIVEAPI_TOKEN`. Show live provider data distinctly from saved and fictional sample data, and provide loading, error, and no-live-match states. Never place the provider token in frontend code, chat, logs, or committed files, and never label sample data as live API data.

## Implementation approach

1. Extend `drizzle/schema.ts` without changing `users`. Add MySQL/Drizzle tables for teams, players, matches, innings, batting scorecards, bowling scorecards, and partnerships. Use foreign keys, uniqueness constraints, indexes, timestamps, and numeric legal-ball counts so overs can be displayed accurately. Keep this an additive schema change.
2. Generate and commit an additive Drizzle SQL migration. Do not apply it to the managed database from tests or development: project guidance confirms the development and published app share one database. Document how to apply it deliberately to a local Windows MySQL database. No destructive SQL.
3. Add typed database query helpers and tRPC endpoints for dashboard match lists, match detail/innings/scorecards/partnerships, player statistics, and SQL analytics. Public read operations may serve persisted data; sample fallback must be labelled. Require the existing `adminProcedure` for create/update/delete operations. Reuse the existing `users` table, session context, and role enforcement.
4. Build a responsive React dashboard in the existing Vite/React shell using scoped CSS, lucide-react, and the already-installed Recharts (no replacement UI/chart stack). Include Live / Upcoming / Completed filters, match score summaries, match detail and player/analytics views, and admin-only CRUD controls. Empty/unmigrated database states must produce a clear setup/sample message rather than a false live status.
5. Add `server/cricket/provider.ts` as a server-only adapter. Read `CRICKETLIVEAPI_TOKEN` at request time and send `Authorization: Bearer <token>` plus `Accept: application/json`; never expose the secret to Vite, browser code, client responses, logs, or committed files.
6. Normalize both observed authenticated envelopes—`{success:true,type:"live",count:N,data:[...]}` (including the successful empty-array response) and the public developer reference's example `{status:"success",data:{matches:[...]}}`—into the existing match-card contract. The actual non-empty item uses nested `first_team`/`second_team` objects plus `series_name`, `match_desc`, `date`, `state`, `status_detail`, and `status`; read team names/codes and scores from those nested records. Prefer structured innings `runs`/`wickets`/`overs` to the provider's flattened team score when they disagree. Only display an overs value with legal ball notation; omit invalid provider values such as `1.6` rather than invent a correction. The official live-line example shows `score` and `overs` as separate fields (e.g. `187/3` and `18.4`).
7. Connect all normalized provider records through the existing public `cricket.matches.list` tRPC path. Map provider `Preview`/`Toss` records to Upcoming; count only actual in-progress states as live. Preserve saved and clearly labelled sample upcoming/completed fixtures. When a successful response has no in-progress match, do not count the fictional sample live fixture as live API data; when the provider is unavailable, label the error and keep existing non-provider behavior clearly identified.
8. Keep the existing editorial scorebug dashboard and responsive layout. Add visible loading/error states, provider connection/error indicators, a no-live-matches message, and provider source labels. Preserve current filters, match details, player room, analytics, and admin-only CRUD.
9. Optimize Free-tier calls with a 30-minute dashboard match-list interval and matching 30-minute backend cache. Set explicit `staleTime` to 30 minutes, keep `retry:false`, and disable focus, reconnect, and background-interval refetches. Preserve server-side in-flight coalescing. For HTTP 429, honor a valid `Retry-After` delta-seconds value or HTTP date; otherwise use exponential backoff starting at 30 minutes and doubling on consecutive 429 responses up to 24 hours. If a valid provider delay is longer, do not retry before it. Cache the 429 result until its computed backoff expires; reset the fallback streak after a non-429 response. One continuously active process then uses about 48 calls/day, leaving 52 calls of the Free 100/day limit; restarts, multiple processes, and other requests still consume allowance.
10. Add focused tests for supported response envelopes, actual nested Preview/Toss and in-progress schemas, status classification, schedule parsing, structured and invalid score fields, malformed responses, empty feeds, and HTTP 429 backoff (`Retry-After` seconds/date, malformed or missing header, repeated 429s, cache suppression, and reset on a non-429 response). Mock all provider requests in tests. Run type checks, the existing test suite, and the production build. Do not start Preview or make live CricketLiveAPI requests for this optimization; do not publish.
11. Do not insert provider data into MySQL or apply migrations for this integration. A real in-progress provider score has already been rendered in Preview, and the Production-scoped secret is configured. Preserve the existing dashboard and API integration. The current work changes only quota policy and tests; publication still requires the user's explicit approval.

## Data model

- `teams`: canonical team name, short name, country and optional logo URL.
- `players`: name, team, playing role, batting style and bowling style.
- `matches`: provider ID (nullable), format, competition, venue, scheduled time, status, two team references, current innings, result/summary, data source and synchronization timestamp.
- `innings`: match, innings number, batting/bowling teams, runs, wickets, completed legal balls, extras, target and innings state.
- `batting_scorecards`: innings/player, batting order, runs, balls faced, boundaries, dismissal and not-out state.
- `bowling_scorecards`: innings/player, completed legal balls, maidens, runs conceded, wickets, wides and no-balls.
- `partnerships`: innings and ordered batters, partnership runs/balls and wicket/end positions.

`users` remains unchanged. Admin writes use the existing admin role guard. SQL aggregates are derived from scorecard/innings rows; sample mode is explicitly identified in the UI. Provider live data is read-only and is not persisted to the shared database; provider match cards use a distinct `cricketliveapi` source marker.

## Project structure

- `client/src/pages/` — dashboard and match detail pages; `Home.tsx` owns the match-list refresh/staleness policy.
- `client/src/components/` — reusable match cards, status/score components, scorecards, analytics and admin forms.
- `client/src/pages/cricket.css` — existing MatchIQ dark editorial scorebug styles and responsive layouts; extend minimally for provider states.
- `shared/cricket-samples.ts` — typed, clearly labelled fictional fixtures/statistics used only when saved/API data is not available; `shared/cricket-utils.ts` holds browser/server-safe calculations.
- `server/cricket/provider.ts` — backend-only CricketLiveAPI authentication, response validation/normalization, 30-minute cache aligned with dashboard polling, and safe rate-limit backoff.
- `server/cricket/readRouter.ts` — public match, detail, player-stat and SQL-analytics tRPC queries; merge provider live data without changing existing admin APIs.
- `server/routers.ts` — compose cricket read and authorized mutation routers into the existing tRPC API.
- `server/cricket/adminRouter.ts` — validated administrator-only cricket CRUD endpoints.
- `server/cricket/logic.ts` — cricket calculation helpers.
- `drizzle/schema.ts`, `drizzle/*.sql`, `drizzle/meta/` — additive Drizzle tables/migration metadata.
- `shared/` — shared TypeScript/Zod input and response types as useful.
- `client/public/manus-routes.json` — synchronized page-route manifest required before starting the dev server.
- `README.md`, `.env.example` — exact beginner-friendly local configuration and Windows 11 setup.

## Design direction

- **Design Movement:** Editorial cricket-data newsroom with the precision of a broadcast scorebug.
- **Core Principles:** Score first; statistics remain legible; live/demo state is unmistakable; controls stay predictable on touch screens.
- **Color Philosophy:** An ink-dark stadium backdrop keeps the data calm and reduces glare; softly contrasted charcoal score panels keep figures legible; boundary-lime marks high-priority actions and live state; muted teal and amber differentiate upcoming and neutral statuses.
- **Layout Paradigm:** A persistent left navigation rail anchors a score-led workspace. Overview pairs the active fixture with a compact quick-read rail, followed by leaderboard and analytics panels; mobile collapses to a slide-in rail and single-column score cards.
- **Signature Elements:** Lime live pulse/status chip; compact monospaced score/over numerals; team initials in circular, color-coded crests.
- **Interaction Philosophy:** Fixture filters update in place; cards open a dedicated match-detail drawer; admin-only forms are separated from public views and confirm deletions.
- **Animation:** Only the live-state pip pulses gently; card hover movement is restrained; there is no invented score animation or implied live provider update.
- **Typography System:** Space Grotesk display headings paired with DM Sans interface text, both with system fallbacks; geometric/tabular score numerals make values easy to compare.
- **Brand Essence:** MatchIQ is a clear, match-centred cricket intelligence dashboard for fans and analysts; **precise, energetic, approachable**.
- **Brand Voice:** Compact, factual, student-friendly labels. Examples: “Scoreboard, without the noise.” “Sample feed — connect a provider to see live scores.”
- **Wordmark & Logo:** “MatchIQ” with a small boundary arc/ball mark drawn using CSS or inline SVG, not an external logo asset.
- **Signature Brand Color:** Boundary lime (`#B7F34A`), reserved for live state and high-priority actions.

## Important constraints

- Preserve `users`, OAuth/session behavior, existing shared procedures and the current route shell.
- `CRICKETLIVEAPI_TOKEN` is configured for Development and Production. Never put it in frontend code, chat, logs, `.env.example`, or Git. A real in-progress score has been visibly verified in Preview. This quota-optimization task uses mocked provider responses only: do not make live API calls or publish.
- The authenticated endpoint first returned a pre-match Preview/Toss fixture, then an In Progress match. The live response's `innings` array contains the reliable runs/wickets/overs. The source can emit nonstandard overs such as `1.6`; suppress such overs rather than presenting them as cricket notation. Do not invent or relabel sample scores as provider data.
- The managed MySQL database is shared across development and publication. Do not insert test data or apply migrations during this integration.
- CRUD is restricted to authenticated administrators via the existing `adminProcedure`.
