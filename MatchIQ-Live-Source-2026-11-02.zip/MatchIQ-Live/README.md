# MatchIQ — Cricket Analytics Dashboard

A responsive cricket dashboard built **inside the existing project architecture**: React + TypeScript + Vite, Node.js + Express + tRPC, MySQL + Drizzle ORM, and Recharts. Existing users and Manus OAuth/session handling are retained.

> **Data status:** CricketLiveAPI is configured server-side for Development/Preview. The authenticated endpoint returned HTTP 200 and recently included one `Preview`/`Toss` fixture with no scores; it is shown as an upcoming provider fixture, not an in-progress live match. Real live-score rendering has not yet been verified. Saved MySQL records and fictional sample fixtures remain source-labelled. Production is not configured or published.

## What is included

- **Match centre:** Live, upcoming, completed and abandoned match filters; teams, scores, overs, wickets, match status and summaries.
- **Match details:** innings, batting and bowling scorecards, partnerships and result/summary.
- **Player room:** runs, wickets, batting average, strike rate and bowling economy.
- **Analytics:** Recharts visualizations; when saved records exist, SQL aggregates read the innings and scorecard tables. Otherwise, clearly labelled demo charts are shown.
- **Data manager:** admin-only create, view, update and delete operations for teams, players, matches, innings, batting/bowling scorecards and partnerships.
- **Refresh behavior:** to honor the user's Free-tier choice, the dashboard checks the live provider every 15 minutes and the server caches the response for the same interval. That is about 96 calls/day for one continuously active server process. The margin under the provider's 100-calls/day limit is small; extra instances or restarts can exceed it, so this setup assumes one process and no forced refreshes. Saved and sample fixtures retain their own source labels.

## Project map

| Path | Responsibility |
| --- | --- |
| `client/src/pages/Home.tsx` | Dashboard shell, navigation and match/player/analytics sections |
| `client/src/pages/cricket.css` | Responsive MatchIQ visual styles |
| `client/src/components/cricket/` | Match cards, details, player stats, charts and admin forms |
| `server/cricket/provider.ts` | Backend-only CricketLiveAPI request, response validation/normalization and cache |
| `server/cricket/readRouter.ts` | Public match, detail, player-stat and SQL-analytics tRPC queries |
| `server/cricket/adminRouter.ts` | Validated administrator-only cricket CRUD endpoints |
| `server/cricket/logic.ts` | Server-facing exports for cricket calculations |
| `shared/cricket-samples.ts` | Fictional sample fixtures/statistics and shared response types |
| `shared/cricket-utils.ts` | Shared overs, batting and bowling calculations |
| `drizzle/schema.ts` | Additive cricket database schema; existing `users` table is retained |
| `drizzle/0001_faithful_kinsey_walden.sql` | New additive cricket tables, keys and indexes |
| `client/public/manus-routes.json` | Root page route manifest |

## Windows 11 setup (PowerShell)

### 1. Install prerequisites

Install **Node.js 22 LTS**, **MySQL 8**, and **Git**. Open PowerShell and install/activate the project’s pnpm version:

```powershell
corepack enable
corepack prepare pnpm@10.18.0 --activate
pnpm --version
```

Open PowerShell in the project folder you downloaded or checked out. Keep this existing project; do not scaffold a replacement app.

### 2. Install packages and create a local database

```powershell
pnpm install
Copy-Item .env.example .env
notepad .env
```

In MySQL Workbench (or the MySQL command line), create a **local development database** and a dedicated user. Replace the example password with your own:

```sql
CREATE DATABASE matchiq CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'matchiq_app'@'localhost' IDENTIFIED BY 'Replace_With_A_Strong_Local_Password';
GRANT ALL PRIVILEGES ON matchiq.* TO 'matchiq_app'@'localhost';
FLUSH PRIVILEGES;
```

Set `DATABASE_URL` in `.env` to the connection for that local database:

```dotenv
DATABASE_URL=mysql://matchiq_app:Replace_With_A_Strong_Local_Password@127.0.0.1:3306/matchiq
PORT=3000
NODE_ENV=development
```

If your password contains URL-reserved symbols (for example `@`, `:`, `/` or `#`), URL-encode those characters in `DATABASE_URL`. Keep `.env` private; do not commit it or put credentials in frontend code.

### 3. Apply the checked-in migrations to the local database

`drizzle.config.ts` reads `DATABASE_URL` from the process environment. In PowerShell, set it for the migration command (use your own local value):

```powershell
$env:DATABASE_URL = "mysql://matchiq_app:Replace_With_A_Strong_Local_Password@127.0.0.1:3306/matchiq"
pnpm exec drizzle-kit migrate
```

The checked-in chain creates the existing `users` baseline first, then adds cricket tables. The new `0001` migration is additive: it creates teams, players, matches, innings, batting/bowling scorecards, partnerships, foreign keys and indexes; it does **not** alter or delete existing users. To remove the temporary PowerShell variable after migration:

```powershell
Remove-Item Env:DATABASE_URL
```

Migration `0001` has now been applied to the managed database shared by Preview and Published deployments. All seven cricket tables were verified present and empty; the existing `users` table remains present. For your laptop, still run the checked-in migration against your separate local MySQL database. For future production/shared migrations, use the project's release procedure; do not run `db:push` against the managed database.

### 4. Run the application

The existing `pnpm dev` script uses Unix-style environment assignment. For Windows PowerShell, set the variable and run the existing TypeScript entry point directly:

```powershell
$env:NODE_ENV = "development"
pnpm exec tsx watch server/_core/index.ts
```

Open **http://localhost:3000**. Health endpoint: **http://localhost:3000/api/health**.

Stop the server with `Ctrl+C`. If port 3000 is busy, set a different port first, for example `$env:PORT = "3001"`, and open `http://localhost:3001`.

### 5. Check tests and production build (optional)

In a second PowerShell window in the project folder:

```powershell
pnpm check
pnpm test
pnpm build
```

To run the built server locally from PowerShell:

```powershell
$env:NODE_ENV = "production"
node dist/index.js
```

## Authentication and data permissions

The project keeps its existing Manus OAuth/session and `users` table. Public users can read the dashboard. **Every data-modifying cricket endpoint uses the existing `adminProcedure` and requires an authenticated user whose existing role is `admin`.** Role checks are performed on the server; hiding a button in the browser is not the security boundary.

For an unauthenticated local read-only demo, leave the Manus OAuth fields blank; sample dashboard screens remain available. Do not invent OAuth values or turn off the admin check. An authenticated admin session needs the real project-provided `MANUS_PROJECT_ID`, `MANUS_JWT_SECRET`, `MANUS_OAUTH_PORTAL_URL`, and `MANUS_OAUTH_API_URL`. Do not paste these values into chat or commit them. On the managed project they are supplied by its existing platform configuration; local OAuth callback policy can also depend on the registered project origin.

## CricketLiveAPI live feed

The existing project uses CricketLiveAPI's `GET https://cricketliveapi.com/api/v1/cricket/matches/live` endpoint through `server/cricket/provider.ts`. The provider's public developer reference specifies `Authorization: Bearer <token>` and `Accept: application/json`. The API key is read only by the server from `CRICKETLIVEAPI_TOKEN`; never use a `VITE_` prefix, expose it in a browser request, put the real value in `.env.example`, or share it in chat. In Manus Preview, configure the protected project secret for **Development**. For local-only Windows testing, put your own provider token in the ignored `.env` file, not in source control.

The provider's public developer example uses `{ "status": "success", "data": { "matches": [...] } }`; the authenticated endpoint returns `{ "success": true, "type": "live", "count": N, "data": [...] }`. The actual rows use `series_name`, `match_desc`, `date`, `state`, `status_detail`, and nested `first_team`/`second_team` objects. A row in `Preview`/`Toss` is classified as Upcoming; a later `In Progress` row was rendered in Preview with the provider's real team, runs, and wickets. The normalizer prefers nested innings `runs`, `wickets`, and `overs` over the provider's flattened score string when they disagree. CricketLiveAPI's public [live-line reference](https://cricketliveapi.com/cricket-live-line-api) shows `score` and `overs` as separate fields (example `187/3`, `18.4`). If a response includes a nonstandard overs value such as `1.6`, MatchIQ omits that overs suffix rather than displaying invalid notation. The signed-in [API docs](https://cricketliveapi.com/api-docs) currently redirect to sign-in.

The provider's [pricing page](https://cricketliveapi.com/pricing) lists live scores on its Free plan with 100 calls/day and 5 requests/minute. The dashboard polls every 30 minutes and the server cache uses the same interval (about 48 calls/day for one continuously active server process, leaving 52 calls of theoretical daily headroom). The cache is in-process only; restarts and multiple server instances can add calls. Match-list focus/reconnect/background refetches are disabled and `staleTime` is explicit. HTTP 429 responses honor a valid `Retry-After`; absent/invalid headers use exponential backoff. A successful response with no in-play matches displays the no-live state; provider Preview/Toss rows appear as upcoming fixtures. Provider errors are shown separately. Sample cards carry a `SAMPLE` badge and a fictional live demo status reads “Sample live”, never “CricketLiveAPI”. Preview previously displayed a real in-progress provider score; this quota-policy code change has not been tested against the live endpoint.

The `CRICKETLIVEAPI_TOKEN` project secret is configured for Development and Production; its value is never shown in project config metadata. Real in-progress score display was verified in Preview before the 30-minute cadence change. The 30-minute cadence/backoff change passed `pnpm check`, all 22 tests, and `pnpm build`; provider requests were mocked and no live endpoint request or publish was made for this change. The Production value has not been exercised in a published runtime. Automatic publishing is off, and publishing still requires the user's explicit approval.

## Troubleshooting

- **`DATABASE_URL is required` during migration:** set `$env:DATABASE_URL` in the same PowerShell window before `pnpm exec drizzle-kit migrate`.
- **Connection refused / access denied:** check that the local MySQL service is running, the database/user were created, and the password/port in `DATABASE_URL` are correct.
- **Dashboard shows sample values:** this is the expected fallback when there are no saved cricket records or the database tables cannot be read. If CricketLiveAPI is successfully connected but returns no live matches, the dashboard still labels non-live sample fixtures and shows the no-live-matches state. Check the feed banner before treating a score as live.
- **Manage data says admin sign-in required:** sign in through the existing project OAuth with an account that already has the `admin` role. Do not bypass the server guard.
- **Scores do not change like a live feed:** check the feed banner. A connected feed may currently have no live matches; errors and missing configuration are reported separately. The provider check interval is 30 minutes to conserve the Free-plan quota.


## Preview, publishing and sharing

The project has a working **Preview** in Manus. Preview is for testing; it is not the permanent published-site URL. Production is currently **not deployed**.

To publish and obtain a shareable website link:

1. Open the **MatchIQ** project in your Manus Dashboard and check its Preview.
2. Use the Dashboard's **Publish** action. This project already has a Node container `Dockerfile`, server/database enabled, and `/api/health` as its readiness path.
3. Wait for Publish to report success; a code push or a healthy Preview alone does not mean the site is published.
4. Copy the **published URL** shown by the successful Publish result or project Dashboard and share that with viewers. A collaborator/project-access link is a separate Share/invite setting.

Automatic publishing is currently off, so later code changes require another manual Publish. The cricket migration is applied to the managed database, but its tables are empty. An actual in-progress CricketLiveAPI score has been rendered in Preview; the dashboard uses structured innings when available and omits nonstandard overs rather than inventing a value. The current 30-minute cadence is estimated at 48 provider calls/day for one continuously active server process; multi-instance hosting or restarts can exceed that estimate. The Production-scoped token is configured but has not been exercised in a published runtime. The Windows MySQL instructions above use a separate laptop database and do not change the managed database.
